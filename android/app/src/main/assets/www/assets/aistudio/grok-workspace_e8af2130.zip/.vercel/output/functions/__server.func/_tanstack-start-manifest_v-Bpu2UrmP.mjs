//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Bpu2UrmP.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-Bs8o3loD.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Bs8o3loD.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BRW0BQVy.js"]
	}
} });
//#endregion
export { tsrStartManifest };
