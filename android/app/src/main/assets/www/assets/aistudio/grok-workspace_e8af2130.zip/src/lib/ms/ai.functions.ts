import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const messageSchema = z.object({
  role: z.enum(["system", "user", "assistant"]),
  content: z.string().min(1).max(6000),
});

const chatSchema = z.object({
  mode: z.enum(["builtin", "custom"]),
  baseUrl: z.string().max(300).optional(),
  apiKey: z.string().max(500).optional(),
  model: z.string().min(1).max(120),
  temperature: z.number().min(0).max(1).optional(),
  messages: z.array(messageSchema).min(1).max(14),
});

const probeSchema = z.object({
  mode: z.enum(["builtin", "custom"]),
  baseUrl: z.string().max(300).optional(),
  apiKey: z.string().max(500).optional(),
});

export type AiResult =
  | { ok: true; text: string; model: string; promptTokens: number; completionTokens: number }
  | { ok: false; error: "no_key" | "bad_url" | "upstream" | "empty" | "network"; detail?: string };

export type ProbeResult =
  | { ok: true; models: string[] }
  | { ok: false; error: "no_key" | "bad_url" | "upstream" | "network"; detail?: string };

function isPublicHttps(raw: string | undefined): URL | null {
  if (!raw) return null;
  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    return null;
  }
  if (url.protocol !== "https:") return null;
  const host = url.hostname.toLowerCase();
  if (!host || host === "localhost" || host.endsWith(".local") || host.endsWith(".internal")) return null;
  if (host.includes(":")) return null;
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host)) {
    const [a, b] = host.split(".").map((part) => Number(part));
    if (a === 10 || a === 127 || a === 0 || (a === 192 && b === 168) || (a === 172 && b >= 16 && b <= 31)) return null;
    if (a === 169 && b === 254) return null;
  }
  return url;
}

function endpoint(mode: "builtin" | "custom", baseUrl: string | undefined): { root: string; key: string } | { error: "no_key" | "bad_url" } | null {
  if (mode === "builtin") {
    const key = process.env.XAI_API_KEY;
    if (!key) return { error: "no_key" };
    return { root: "https://api.x.ai/v1", key };
  }
  return null;
}

async function readJson(res: Response): Promise<unknown> {
  try {
    return await res.json();
  } catch {
    return null;
  }
}

export const askTutor = createServerFn({ method: "POST" })
  .validator((input: unknown) => chatSchema.parse(input))
  .handler(async ({ data }): Promise<AiResult> => {
    try {
      let root = "";
      let key = "";
      if (data.mode === "builtin") {
        const built = endpoint("builtin", undefined);
        if (!built) return { ok: false, error: "no_key" };
        if ("error" in built) return { ok: false, error: built.error };
        root = built.root;
        key = built.key;
      } else {
        const url = isPublicHttps(data.baseUrl);
        if (!url || !data.apiKey) return { ok: false, error: data.apiKey ? "bad_url" : "no_key" };
        root = url.toString().replace(/\/$/, "");
        key = data.apiKey;
      }
      const res = await fetch(`${root}/chat/completions`, {
        method: "POST",
        redirect: "manual",
        signal: AbortSignal.timeout(25000),
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
        body: JSON.stringify({
          model: data.model,
          temperature: data.temperature ?? 0.4,
          max_tokens: 700,
          messages: data.messages,
        }),
      });
      if (res.status >= 300 && res.status < 400) return { ok: false, error: "bad_url", detail: "redirect" };
      if (!res.ok) return { ok: false, error: "upstream", detail: `HTTP ${res.status}` };
      const body = (await readJson(res)) as {
        choices?: { message?: { content?: string } }[];
        usage?: { prompt_tokens?: number; completion_tokens?: number };
        model?: string;
      } | null;
      const text = body?.choices?.[0]?.message?.content?.trim() ?? "";
      if (!text) return { ok: false, error: "empty" };
      return {
        ok: true,
        text,
        model: body?.model || data.model,
        promptTokens: body?.usage?.prompt_tokens ?? 0,
        completionTokens: body?.usage?.completion_tokens ?? 0,
      };
    } catch {
      return { ok: false, error: "network" };
    }
  });

export const probeModels = createServerFn({ method: "POST" })
  .validator((input: unknown) => probeSchema.parse(input))
  .handler(async ({ data }): Promise<ProbeResult> => {
    try {
      let root = "";
      let key = "";
      if (data.mode === "builtin") {
        const built = endpoint("builtin", undefined);
        if (!built) return { ok: false, error: "no_key" };
        if ("error" in built) return { ok: false, error: built.error };
        root = built.root;
        key = built.key;
      } else {
        const url = isPublicHttps(data.baseUrl);
        if (!url || !data.apiKey) return { ok: false, error: data.apiKey ? "bad_url" : "no_key" };
        root = url.toString().replace(/\/$/, "");
        key = data.apiKey;
      }
      const res = await fetch(`${root}/models`, {
        method: "GET",
        redirect: "manual",
        signal: AbortSignal.timeout(20000),
        headers: { Authorization: `Bearer ${key}` },
      });
      if (res.status >= 300 && res.status < 400) return { ok: false, error: "bad_url", detail: "redirect" };
      if (!res.ok) return { ok: false, error: "upstream", detail: `HTTP ${res.status}` };
      const body = (await readJson(res)) as { data?: { id?: string }[] } | null;
      const models = (body?.data ?? []).map((item) => item.id).filter((id): id is string => Boolean(id)).slice(0, 40);
      return { ok: true, models };
    } catch {
      return { ok: false, error: "network" };
    }
  });
