import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as object, i as number, n as array, o as string, t as _enum } from "../_libs/zod.mjs";
import { a as ListChecks, c as Clock, d as Building2, f as BookOpen, i as Settings, l as CalendarDays, o as House, p as Bell, r as Sparkles, s as Ellipsis, t as Users, u as Cable } from "../_libs/lucide-react.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C3zED8Qv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var messageSchema = object({
	role: _enum([
		"system",
		"user",
		"assistant"
	]),
	content: string().min(1).max(6e3)
});
var chatSchema = object({
	mode: _enum(["builtin", "custom"]),
	baseUrl: string().max(300).optional(),
	apiKey: string().max(500).optional(),
	model: string().min(1).max(120),
	temperature: number().min(0).max(1).optional(),
	messages: array(messageSchema).min(1).max(14)
});
var probeSchema = object({
	mode: _enum(["builtin", "custom"]),
	baseUrl: string().max(300).optional(),
	apiKey: string().max(500).optional()
});
var askTutor = createServerFn({ method: "POST" }).validator((input) => chatSchema.parse(input)).handler(createSsrRpc("b134fc1c499c669c146385a719b68437fc5929d3f096f5734c523502741f7e17"));
var probeModels = createServerFn({ method: "POST" }).validator((input) => probeSchema.parse(input)).handler(createSsrRpc("901ee8d50ebdbf3eaf90c1ab6c0486388b9ad8856a67f77c14b5ff202dcf2080"));
function uid() {
	if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") return crypto.randomUUID();
	return `id-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}
var ru = {
	appName: "MetaШкола",
	welcomeTitle: "Одна среда для учёбы",
	welcomeLead: "Семья, личный день и школа живут рядом. Данные этого запуска хранятся на устройстве и работают без регистрации.",
	openDemo: "Открыть пример лицея",
	demoHint: "Родина Коваленко и лицей «Горизонт». Олена видит детей, Марко — только своё.",
	startEmpty: "Пустое пространство",
	yourName: "Ваше имя",
	spaceName: "Название пространства",
	modeFamily: "Семья",
	modePersonal: "Личное",
	modeSchool: "Школа",
	continue: "Создать",
	authorLine: "Автор концепции — Andárer",
	home: "Главная",
	schedule: "Расписание",
	tasks: "Задания",
	calendar: "Календарь",
	more: "Ещё",
	bells: "Звонки",
	ai: "MetaAI",
	people: "Люди",
	orgs: "Организации",
	integrations: "Интеграции",
	settings: "Настройки",
	save: "Сохранить",
	cancel: "Отмена",
	delete: "Удалить",
	add: "Добавить",
	close: "Закрыть",
	edit: "Изменить",
	today: "Сегодня",
	tomorrow: "Завтра",
	nextStudy: "Ближайший учебный день",
	noLessons: "Уроков нет",
	room: "Кабинет",
	teacher: "Преподаватель",
	subject: "Предмет",
	due: "Срок",
	status: "Статус",
	priority: "Приоритет",
	comment: "Комментарий",
	comments: "Комментарии",
	noAccess: "Этой роли действие недоступно.",
	inbox: "Уведомления",
	inboxEmpty: "Пока тихо. Напоминания о звонках приходят, пока приложение открыто.",
	markRead: "Прочитать",
	switchProfile: "Кто сейчас",
	switchSpace: "Пространство",
	pinTitle: "PIN профиля",
	pinWrong: "Неверный PIN",
	unlock: "Открыть",
	role_creator: "Создатель",
	role_sysadmin: "Системный админ",
	role_orgAdmin: "Админ организации",
	role_familyAdmin: "Админ семьи",
	role_parent: "Родитель",
	role_teacher: "Преподаватель",
	role_homeroom: "Классный руководитель",
	role_student: "Ученик",
	role_guest: "Гость",
	st_assigned: "Назначено",
	st_progress: "В работе",
	st_done: "Сдано",
	st_checked: "Проверено",
	st_returned: "На доработку",
	pr_low: "Низкий",
	pr_normal: "Обычный",
	pr_high: "Высокий",
	ev_study: "Учебный день",
	ev_weekend: "Выходной",
	ev_vacation: "Каникулы",
	ev_holiday: "Праздник",
	ev_test: "Контрольная",
	ev_exam: "Экзамен",
	ev_event: "Мероприятие",
	ev_personal: "Личное",
	ev_meeting: "Собрание",
	gk_mark: "Оценка",
	gk_test: "Контрольная",
	gk_achievement: "Достижение",
	mon: "Пн",
	tue: "Вт",
	wed: "Ср",
	thu: "Чт",
	fri: "Пт",
	sat: "Сб",
	sun: "Вс",
	lesson: "Урок {n}",
	cancelled: "Отменён",
	replaced: "Замена",
	phaseBefore: "До урока",
	phaseLesson: "Идёт урок",
	phaseBreak: "Перемена",
	phaseAfter: "Уроки закончились",
	phaseEmpty: "В этот день уроков нет",
	minutes: "{n} мин",
	now: "Сейчас",
	bellSettings: "Сетка звонков",
	firstLesson: "Первый урок",
	lessonLen: "Урок, мин",
	breakLen: "Перемена, мин",
	bigBreak: "Большая перемена, мин",
	bigAfter: "После урока №",
	perDay: "Уроков в дне",
	copyDay: "Скопировать день",
	copyTo: "На дни",
	exception: "Исключение на дату",
	exCancel: "Отменить урок",
	exReplace: "Заменить",
	date: "Дата",
	index: "Номер урока",
	note: "Заметка",
	addLesson: "Добавить урок",
	myWatch: "Чьё расписание",
	assignee: "Кому",
	detail: "Условие",
	attachment: "Ссылка на материал",
	fileLimit: "Файл больше 180 КБ. Вставьте ссылку.",
	newTask: "Новое задание",
	feedback: "Отзыв учителя",
	takeProgress: "Взять в работу",
	markDone: "Сдать",
	markChecked: "Принять",
	markReturned: "Вернуть",
	grades: "Оценки",
	score: "Балл 1–12",
	newGrade: "Новая оценка",
	newEvent: "Новое событие",
	title: "Название",
	kind: "Тип",
	classLabel: "Класс",
	allOpen: "Открытые",
	allTasks: "Все",
	noTasks: "Заданий не видно этой роли.",
	noEvents: "В этот день пусто.",
	peopleLead: "Несколько человек на одном устройстве. Роль решает, что можно менять.",
	addPerson: "Добавить человека",
	roles: "Роли",
	children: "Дети",
	setPin: "Задать PIN",
	clearPin: "Снять PIN",
	pinPh: "4 цифры",
	orgLead: "Школа: организация, подразделение, класс, группа.",
	familyLead: "Семейное пространство. Школьные классы живут в школьном пространстве.",
	personalLead: "Личное пространство: своё расписание, задания и календарь.",
	division: "Подразделение",
	group: "Группа",
	period: "Учебный период",
	homeroom: "Классный руководитель",
	subjectName: "Название предмета",
	minorAi: "Ограничить MetaAI для учеников",
	minorAiHint: "Ученик видит заглушку. Взрослые роли продолжают работать.",
	aiLead: "Встроенный Grok отвечает через ключ платформы. Свои ключи остаются на устройстве и уходят на сервер только в момент запроса.",
	aiBlocked: "Для учеников в этом пространстве MetaAI выключен взрослым.",
	aiNoGrant: "У этой роли нет доступа к ИИ.",
	assistant: "Помощник",
	model: "Модель",
	send: "Спросить",
	thinking: "Думаю…",
	compare: "Сравнить две модели",
	secondModel: "Вторая модель",
	usage: "Расход",
	tokens: "{p} / {c} токенов",
	usageEmpty: "Запросов ещё не было.",
	newAssistant: "Свой помощник",
	instruction: "Инструкция помощнику",
	providers: "Провайдеры",
	probe: "Проверить соединение",
	probeOk: "Соединение есть. Моделей: {n}",
	apiKey: "API-ключ",
	baseUrl: "Endpoint",
	addProvider: "Подключить",
	builtinKey: "Ключ платформы, вводить не нужно",
	temperature: "Температура",
	catalogNote: "Anthropic Claude напрямую несовместим с этим шлюзом. Claude, Gemini и другие можно подключить через OpenRouter или их OpenAI-совместимый адрес.",
	err_no_key: "Нет ключа. Для Grok он выдаётся платформой и сейчас недоступен.",
	err_bad_url: "Нужен публичный адрес https. Локальные и служебные адреса закрыты.",
	err_upstream: "Сервис ответил ошибкой",
	err_empty: "Пустой ответ",
	err_network: "Сеть или тайм-аут",
	err_format: "Файл не похож на базу MetaШколы.",
	integrationsLead: "Правила выборочной синхронизации хранятся здесь. Живой вход в Google, Microsoft и Telegram в этой сборке не подключён — внешний сервис не вызывается.",
	accountLabel: "Метка аккаунта",
	enableRule: "Правило",
	direction: "Направление",
	dataKind: "Данные",
	frequency: "Частота",
	dir_import: "Только получить",
	dir_export: "Только отдать",
	dir_both: "В обе стороны",
	data_calendar: "Календарь",
	data_materials: "Материалы",
	data_notifications: "Уведомления",
	data_tasks: "Задания",
	freq_manual: "Вручную",
	freq_daily: "Раз в день, когда откроете",
	who: "Для кого",
	everyone: "Все профили",
	runSync: "Записать попытку",
	syncHonest: "Внешний сервис не вызывался: OAuth не подключён. Правило и журнал — настоящие.",
	exportIcs: "Скачать календарь ICS",
	journal: "Журнал",
	journalEmpty: "Журнал пуст.",
	svc_google_calendar: "Google Calendar",
	svc_google_drive: "Google Drive",
	svc_gmail: "Gmail",
	svc_classroom: "Google Classroom",
	svc_outlook: "Outlook",
	svc_onedrive: "OneDrive",
	svc_ms_calendar: "Календарь Microsoft",
	svc_telegram: "Telegram",
	svc_caldav: "CalDAV",
	svc_webdav: "WebDAV",
	svc_rest: "Свой REST",
	theme: "Тема",
	themeLight: "Светлая",
	themeDark: "Тёмная",
	themeSystem: "Системная",
	language: "Язык",
	notif: "Локальные уведомления",
	notifHint: "Звонки, перемены и сроки срабатывают, только пока MetaШкола открыта. Фоновые будильники Android в веб-сборке недоступны.",
	notifBrowser: "Разрешить уведомления браузера",
	notifGranted: "Браузер разрешил уведомления",
	notifDenied: "Браузер запретил уведомления",
	n_lessonStart: "Начало урока",
	n_lessonEnd: "Конец урока",
	n_breakStart: "Начало перемены",
	n_breakEnd: "Конец перемены",
	n_remind15: "За 15 минут",
	n_remind5: "За 5 минут",
	n_tasks: "Срок задания",
	n_personal: "Личные события",
	cloudNotif: "Облачные уведомления (новые задания с сервера, объявления школы) не доставляются: облако MetaШколы не развёрнуто.",
	exportJson: "Скачать JSON",
	includeSecrets: "Включить PIN и API-ключи",
	importJson: "Импорт JSON",
	replace: "Заменить всё",
	merge: "Объединить по id",
	imported: "Импорт выполнен",
	reset: "Стереть данные устройства",
	resetConfirm: "Удалить локальную базу и вернуться к началу?",
	about: "О приложении",
	aboutBody: "MetaШкола 2.0 — модульная образовательная среда. Автор и создатель концепции: Andárer. Авторство не зависит от ролей в приложении.",
	delivery: "Эта сборка — рабочее веб-приложение с локальной базой. Подписанный APK для OPPO A74, сервер MetaШколы, живой OAuth и фоновые будильники Android здесь не реализованы и не имитируются.",
	architecture: "Что уже работает",
	archOk: "Локальные профили и роли, семья и школа, расписание до 12 уроков, звонки, исключения, задания, оценки, календарь, журнал действий, JSON, ICS, правила синхронизации, MetaAI.",
	archNo: "Не сделано в этой поставке: облачные аккаунты и мультиарендный сервер, push вне открытого окна, двусторонняя связь с Google и Microsoft, нативный Android.",
	audit: "Журнал действий",
	customRole: "Своя роль",
	roleName: "Имя роли",
	reports: "Сводка",
	openTasks: "Открытые задания",
	avg: "Средний балл",
	none: "Нет",
	namePh: "Имя",
	askPh: "Спросите так, чтобы осталось что решить самому",
	linkPh: "https://…",
	wd1: "Понедельник",
	wd2: "Вторник",
	wd3: "Среда",
	wd4: "Четверг",
	wd5: "Пятница",
	wd6: "Суббота",
	wd7: "Воскресенье",
	forWhom: "Для",
	history: "История",
	preset: "Каталог",
	langAnswer: "Отвечай на русском языке.",
	bellIn: "Звонок через {t}",
	untilEnd: "До конца {t}",
	free: "Свободно",
	addSpace: "Ещё одно пространство",
	addSpaceLead: "Семья, личный день и школа остаются на этом устройстве рядом.",
	joinExisting: "Уже есть в другом пространстве",
	joinLead: "Человек получит роль здесь и не потеряет остальные.",
	bySubject: "По предметам",
	homeroomPick: "Классный руководитель"
};
var dictionaries = {
	ru,
	uk: {
		appName: "MetaШкола",
		welcomeTitle: "Одне середовище для навчання",
		welcomeLead: "Родина, особистий день і школа живуть поруч. Дані цього запуску зберігаються на пристрої й працюють без реєстрації.",
		openDemo: "Відкрити приклад ліцею",
		demoHint: "Родина Коваленко і ліцей «Горизонт». Олена бачить дітей, Марко — лише своє.",
		startEmpty: "Порожній простір",
		yourName: "Ваше ім’я",
		spaceName: "Назва простору",
		modeFamily: "Родина",
		modePersonal: "Особисте",
		modeSchool: "Школа",
		continue: "Створити",
		authorLine: "Автор концепції — Andárer",
		home: "Головна",
		schedule: "Розклад",
		tasks: "Завдання",
		calendar: "Календар",
		more: "Ще",
		bells: "Дзвінки",
		ai: "MetaAI",
		people: "Люди",
		orgs: "Організації",
		integrations: "Інтеграції",
		settings: "Налаштування",
		save: "Зберегти",
		cancel: "Скасувати",
		delete: "Видалити",
		add: "Додати",
		close: "Закрити",
		edit: "Змінити",
		today: "Сьогодні",
		tomorrow: "Завтра",
		nextStudy: "Найближчий навчальний день",
		noLessons: "Уроків немає",
		room: "Кабінет",
		teacher: "Викладач",
		subject: "Предмет",
		due: "Термін",
		status: "Статус",
		priority: "Пріоритет",
		comment: "Коментар",
		comments: "Коментарі",
		noAccess: "Цій ролі дія недоступна.",
		inbox: "Сповіщення",
		inboxEmpty: "Поки тихо. Нагадування про дзвінки приходять, доки застосунок відкритий.",
		markRead: "Прочитати",
		switchProfile: "Хто зараз",
		switchSpace: "Простір",
		pinTitle: "PIN профілю",
		pinWrong: "Невірний PIN",
		unlock: "Відкрити",
		role_creator: "Творець",
		role_sysadmin: "Системний адмін",
		role_orgAdmin: "Адмін організації",
		role_familyAdmin: "Адмін родини",
		role_parent: "Батько або мати",
		role_teacher: "Викладач",
		role_homeroom: "Класний керівник",
		role_student: "Учень",
		role_guest: "Гість",
		st_assigned: "Призначено",
		st_progress: "У роботі",
		st_done: "Здано",
		st_checked: "Перевірено",
		st_returned: "На доопрацювання",
		pr_low: "Низький",
		pr_normal: "Звичайний",
		pr_high: "Високий",
		ev_study: "Навчальний день",
		ev_weekend: "Вихідний",
		ev_vacation: "Канікули",
		ev_holiday: "Свято",
		ev_test: "Контрольна",
		ev_exam: "Іспит",
		ev_event: "Захід",
		ev_personal: "Особисте",
		ev_meeting: "Збори",
		gk_mark: "Оцінка",
		gk_test: "Контрольна",
		gk_achievement: "Досягнення",
		mon: "Пн",
		tue: "Вт",
		wed: "Ср",
		thu: "Чт",
		fri: "Пт",
		sat: "Сб",
		sun: "Нд",
		lesson: "Урок {n}",
		cancelled: "Скасовано",
		replaced: "Заміна",
		phaseBefore: "До уроку",
		phaseLesson: "Триває урок",
		phaseBreak: "Перерва",
		phaseAfter: "Уроки закінчились",
		phaseEmpty: "Цього дня уроків немає",
		minutes: "{n} хв",
		now: "Зараз",
		bellSettings: "Сітка дзвінків",
		firstLesson: "Перший урок",
		lessonLen: "Урок, хв",
		breakLen: "Перерва, хв",
		bigBreak: "Велика перерва, хв",
		bigAfter: "Після уроку №",
		perDay: "Уроків у дні",
		copyDay: "Скопіювати день",
		copyTo: "На дні",
		exception: "Виняток на дату",
		exCancel: "Скасувати урок",
		exReplace: "Замінити",
		date: "Дата",
		index: "Номер уроку",
		note: "Нотатка",
		addLesson: "Додати урок",
		myWatch: "Чий розклад",
		assignee: "Кому",
		detail: "Умова",
		attachment: "Посилання на матеріал",
		fileLimit: "Файл більший за 180 КБ. Вставте посилання.",
		newTask: "Нове завдання",
		feedback: "Відгук учителя",
		takeProgress: "Узяти в роботу",
		markDone: "Здати",
		markChecked: "Прийняти",
		markReturned: "Повернути",
		grades: "Оцінки",
		score: "Бал 1–12",
		newGrade: "Нова оцінка",
		newEvent: "Нова подія",
		title: "Назва",
		kind: "Тип",
		classLabel: "Клас",
		allOpen: "Відкриті",
		allTasks: "Усі",
		noTasks: "Завдань цій ролі не видно.",
		noEvents: "Цього дня порожньо.",
		peopleLead: "Кілька людей на одному пристрої. Роль вирішує, що можна змінювати.",
		addPerson: "Додати людину",
		roles: "Ролі",
		children: "Діти",
		setPin: "Задати PIN",
		clearPin: "Зняти PIN",
		pinPh: "4 цифри",
		orgLead: "Школа: організація, підрозділ, клас, група.",
		familyLead: "Родинний простір. Шкільні класи живуть у шкільному просторі.",
		personalLead: "Особистий простір: свій розклад, завдання і календар.",
		division: "Підрозділ",
		group: "Група",
		period: "Навчальний період",
		homeroom: "Класний керівник",
		subjectName: "Назва предмета",
		minorAi: "Обмежити MetaAI для учнів",
		minorAiHint: "Учень бачить заглушку. Дорослі ролі працюють далі.",
		aiLead: "Вбудований Grok відповідає через ключ платформи. Власні ключі лишаються на пристрої й ідуть на сервер лише в момент запиту.",
		aiBlocked: "Для учнів у цьому просторі MetaAI вимкнено дорослим.",
		aiNoGrant: "У цієї ролі немає доступу до ШІ.",
		assistant: "Помічник",
		model: "Модель",
		send: "Запитати",
		thinking: "Думаю…",
		compare: "Порівняти дві моделі",
		secondModel: "Друга модель",
		usage: "Витрата",
		tokens: "{p} / {c} токенів",
		usageEmpty: "Запитів ще не було.",
		newAssistant: "Власний помічник",
		instruction: "Інструкція помічнику",
		providers: "Провайдери",
		probe: "Перевірити з’єднання",
		probeOk: "З’єднання є. Моделей: {n}",
		apiKey: "API-ключ",
		baseUrl: "Endpoint",
		addProvider: "Підключити",
		builtinKey: "Ключ платформи, вводити не потрібно",
		temperature: "Температура",
		catalogNote: "Anthropic Claude напряму несумісний із цим шлюзом. Claude, Gemini та інших можна підключити через OpenRouter або їхню OpenAI-сумісну адресу.",
		err_no_key: "Немає ключа. Для Grok його дає платформа, і зараз він недоступний.",
		err_bad_url: "Потрібна публічна адреса https. Локальні та службові адреси закриті.",
		err_upstream: "Сервіс відповів помилкою",
		err_empty: "Порожня відповідь",
		err_network: "Мережа або тайм-аут",
		err_format: "Файл не схожий на базу MetaШколи.",
		integrationsLead: "Правила вибіркової синхронізації зберігаються тут. Живий вхід у Google, Microsoft і Telegram у цій збірці не підключений — зовнішній сервіс не викликається.",
		accountLabel: "Мітка акаунта",
		enableRule: "Правило",
		direction: "Напрям",
		dataKind: "Дані",
		frequency: "Частота",
		dir_import: "Лише отримати",
		dir_export: "Лише віддати",
		dir_both: "В обидва боки",
		data_calendar: "Календар",
		data_materials: "Матеріали",
		data_notifications: "Сповіщення",
		data_tasks: "Завдання",
		freq_manual: "Вручну",
		freq_daily: "Раз на день, коли відкриєте",
		who: "Для кого",
		everyone: "Усі профілі",
		runSync: "Записати спробу",
		syncHonest: "Зовнішній сервіс не викликався: OAuth не підключено. Правило і журнал — справжні.",
		exportIcs: "Завантажити календар ICS",
		journal: "Журнал",
		journalEmpty: "Журнал порожній.",
		svc_google_calendar: "Google Calendar",
		svc_google_drive: "Google Drive",
		svc_gmail: "Gmail",
		svc_classroom: "Google Classroom",
		svc_outlook: "Outlook",
		svc_onedrive: "OneDrive",
		svc_ms_calendar: "Календар Microsoft",
		svc_telegram: "Telegram",
		svc_caldav: "CalDAV",
		svc_webdav: "WebDAV",
		svc_rest: "Власний REST",
		theme: "Тема",
		themeLight: "Світла",
		themeDark: "Темна",
		themeSystem: "Системна",
		language: "Мова",
		notif: "Локальні сповіщення",
		notifHint: "Дзвінки, перерви й терміни спрацьовують, лише доки MetaШкола відкрита. Фонові будильники Android у вебзбірці недоступні.",
		notifBrowser: "Дозволити сповіщення браузера",
		notifGranted: "Браузер дозволив сповіщення",
		notifDenied: "Браузер заборонив сповіщення",
		n_lessonStart: "Початок уроку",
		n_lessonEnd: "Кінець уроку",
		n_breakStart: "Початок перерви",
		n_breakEnd: "Кінець перерви",
		n_remind15: "За 15 хвилин",
		n_remind5: "За 5 хвилин",
		n_tasks: "Термін завдання",
		n_personal: "Особисті події",
		cloudNotif: "Хмарні сповіщення (нові завдання з сервера, оголошення школи) не доставляються: хмару MetaШколи не розгорнуто.",
		exportJson: "Завантажити JSON",
		includeSecrets: "Включити PIN і API-ключі",
		importJson: "Імпорт JSON",
		replace: "Замінити все",
		merge: "Об’єднати за id",
		imported: "Імпорт виконано",
		reset: "Стерти дані пристрою",
		resetConfirm: "Видалити локальну базу і повернутися на початок?",
		about: "Про застосунок",
		aboutBody: "MetaШкола 2.0 — модульне освітнє середовище. Автор і творець концепції: Andárer. Авторство не залежить від ролей у застосунку.",
		delivery: "Ця збірка — робочий вебзастосунок із локальною базою. Підписаний APK для OPPO A74, сервер MetaШколи, живий OAuth і фонові будильники Android тут не реалізовані й не імітуються.",
		architecture: "Що вже працює",
		archOk: "Локальні профілі й ролі, родина і школа, розклад до 12 уроків, дзвінки, винятки, завдання, оцінки, календар, журнал дій, JSON, ICS, правила синхронізації, MetaAI.",
		archNo: "Не зроблено в цій поставці: хмарні акаунти і мультитенантний сервер, push поза відкритим вікном, двосторонній зв’язок із Google і Microsoft, нативний Android.",
		audit: "Журнал дій",
		customRole: "Власна роль",
		roleName: "Ім’я ролі",
		reports: "Зведення",
		openTasks: "Відкриті завдання",
		avg: "Середній бал",
		none: "Немає",
		namePh: "Ім’я",
		askPh: "Запитайте так, щоб лишилось що вирішити самому",
		linkPh: "https://…",
		wd1: "Понеділок",
		wd2: "Вівторок",
		wd3: "Середа",
		wd4: "Четвер",
		wd5: "П’ятниця",
		wd6: "Субота",
		wd7: "Неділя",
		forWhom: "Для",
		history: "Історія",
		preset: "Каталог",
		langAnswer: "Відповідай українською мовою.",
		bellIn: "Дзвінок через {t}",
		untilEnd: "До кінця {t}",
		free: "Вільно",
		addSpace: "Ще один простір",
		addSpaceLead: "Сім'я, особистий день і школа лишаються на цьому пристрої поруч.",
		joinExisting: "Уже є в іншому просторі",
		joinLead: "Людина отримає роль тут і не втратить інші.",
		bySubject: "За предметами",
		homeroomPick: "Класний керівник"
	},
	en: {
		appName: "MetaShkola",
		welcomeTitle: "One place for school life",
		welcomeLead: "Family, a personal day, and a school sit side by side. This run keeps data on the device and does not ask you to register.",
		openDemo: "Open the sample lyceum",
		demoHint: "The Kovalenko family and Horizon Lyceum. Olena sees the children; Marko sees only his own work.",
		startEmpty: "Empty space",
		yourName: "Your name",
		spaceName: "Space name",
		modeFamily: "Family",
		modePersonal: "Personal",
		modeSchool: "School",
		continue: "Create",
		authorLine: "Concept author — Andárer",
		home: "Home",
		schedule: "Schedule",
		tasks: "Tasks",
		calendar: "Calendar",
		more: "More",
		bells: "Bells",
		ai: "MetaAI",
		people: "People",
		orgs: "Organizations",
		integrations: "Integrations",
		settings: "Settings",
		save: "Save",
		cancel: "Cancel",
		delete: "Delete",
		add: "Add",
		close: "Close",
		edit: "Edit",
		today: "Today",
		tomorrow: "Tomorrow",
		nextStudy: "Next school day",
		noLessons: "No lessons",
		room: "Room",
		teacher: "Teacher",
		subject: "Subject",
		due: "Due",
		status: "Status",
		priority: "Priority",
		comment: "Comment",
		comments: "Comments",
		noAccess: "This role cannot do that.",
		inbox: "Notices",
		inboxEmpty: "Quiet for now. Bell reminders fire while the app stays open.",
		markRead: "Mark read",
		switchProfile: "Who is here",
		switchSpace: "Space",
		pinTitle: "Profile PIN",
		pinWrong: "Wrong PIN",
		unlock: "Unlock",
		role_creator: "Creator",
		role_sysadmin: "System admin",
		role_orgAdmin: "Organization admin",
		role_familyAdmin: "Family admin",
		role_parent: "Parent",
		role_teacher: "Teacher",
		role_homeroom: "Homeroom teacher",
		role_student: "Student",
		role_guest: "Guest",
		st_assigned: "Assigned",
		st_progress: "In progress",
		st_done: "Handed in",
		st_checked: "Checked",
		st_returned: "Returned",
		pr_low: "Low",
		pr_normal: "Normal",
		pr_high: "High",
		ev_study: "School day",
		ev_weekend: "Weekend",
		ev_vacation: "Break",
		ev_holiday: "Holiday",
		ev_test: "Test",
		ev_exam: "Exam",
		ev_event: "Event",
		ev_personal: "Personal",
		ev_meeting: "Meeting",
		gk_mark: "Mark",
		gk_test: "Test",
		gk_achievement: "Achievement",
		mon: "Mon",
		tue: "Tue",
		wed: "Wed",
		thu: "Thu",
		fri: "Fri",
		sat: "Sat",
		sun: "Sun",
		lesson: "Lesson {n}",
		cancelled: "Cancelled",
		replaced: "Changed",
		phaseBefore: "Before class",
		phaseLesson: "In class",
		phaseBreak: "Break",
		phaseAfter: "Day is over",
		phaseEmpty: "No lessons this day",
		minutes: "{n} min",
		now: "Now",
		bellSettings: "Bell grid",
		firstLesson: "First lesson",
		lessonLen: "Lesson, min",
		breakLen: "Break, min",
		bigBreak: "Long break, min",
		bigAfter: "After lesson #",
		perDay: "Lessons per day",
		copyDay: "Copy this day",
		copyTo: "Onto days",
		exception: "Exception on a date",
		exCancel: "Cancel lesson",
		exReplace: "Replace",
		date: "Date",
		index: "Lesson number",
		note: "Note",
		addLesson: "Add lesson",
		myWatch: "Whose schedule",
		assignee: "Assigned to",
		detail: "Instructions",
		attachment: "Link to material",
		fileLimit: "File is over 180 KB. Paste a link instead.",
		newTask: "New task",
		feedback: "Teacher note",
		takeProgress: "Start",
		markDone: "Hand in",
		markChecked: "Accept",
		markReturned: "Return",
		grades: "Marks",
		score: "Score 1–12",
		newGrade: "New mark",
		newEvent: "New event",
		title: "Title",
		kind: "Type",
		classLabel: "Class",
		allOpen: "Open",
		allTasks: "All",
		noTasks: "This role cannot see any tasks.",
		noEvents: "Nothing on this day.",
		peopleLead: "Several people on one device. The role decides what can change.",
		addPerson: "Add a person",
		roles: "Roles",
		children: "Children",
		setPin: "Set PIN",
		clearPin: "Clear PIN",
		pinPh: "4 digits",
		orgLead: "School: organization, division, class, group.",
		familyLead: "Family space. School classes live in the school space.",
		personalLead: "Personal space: your own timetable, tasks, and calendar.",
		division: "Division",
		group: "Group",
		period: "Term",
		homeroom: "Homeroom teacher",
		subjectName: "Subject name",
		minorAi: "Restrict MetaAI for students",
		minorAiHint: "Students see a lock. Adult roles keep access.",
		aiLead: "Built-in Grok uses the platform key. Your own keys stay on the device and are sent only when you ask.",
		aiBlocked: "An adult turned MetaAI off for students in this space.",
		aiNoGrant: "This role cannot use AI.",
		assistant: "Assistant",
		model: "Model",
		send: "Ask",
		thinking: "Thinking…",
		compare: "Compare two models",
		secondModel: "Second model",
		usage: "Usage",
		tokens: "{p} / {c} tokens",
		usageEmpty: "No requests yet.",
		newAssistant: "Custom assistant",
		instruction: "Instruction",
		providers: "Providers",
		probe: "Test connection",
		probeOk: "Connected. Models: {n}",
		apiKey: "API key",
		baseUrl: "Endpoint",
		addProvider: "Connect",
		builtinKey: "Platform key, nothing to paste",
		temperature: "Temperature",
		catalogNote: "Anthropic Claude is not directly compatible with this gateway. Reach Claude, Gemini, and others through OpenRouter or an OpenAI-compatible URL.",
		err_no_key: "No key. Grok uses the platform key, and it is not available right now.",
		err_bad_url: "A public https address is required. Local and link-local hosts are blocked.",
		err_upstream: "The service returned an error",
		err_empty: "Empty reply",
		err_network: "Network or timeout",
		err_format: "This file is not a MetaShkola database.",
		integrationsLead: "Selective sync rules live here. Live sign-in to Google, Microsoft, and Telegram is not connected in this build — those services are not called.",
		accountLabel: "Account label",
		enableRule: "Rule",
		direction: "Direction",
		dataKind: "Data",
		frequency: "Frequency",
		dir_import: "Import only",
		dir_export: "Export only",
		dir_both: "Both ways",
		data_calendar: "Calendar",
		data_materials: "Materials",
		data_notifications: "Notices",
		data_tasks: "Tasks",
		freq_manual: "Manual",
		freq_daily: "Daily, when you open the app",
		who: "Who",
		everyone: "All profiles",
		runSync: "Record an attempt",
		syncHonest: "The outside service was not called: OAuth is not connected. The rule and the log are real.",
		exportIcs: "Download calendar ICS",
		journal: "Log",
		journalEmpty: "The log is empty.",
		svc_google_calendar: "Google Calendar",
		svc_google_drive: "Google Drive",
		svc_gmail: "Gmail",
		svc_classroom: "Google Classroom",
		svc_outlook: "Outlook",
		svc_onedrive: "OneDrive",
		svc_ms_calendar: "Microsoft Calendar",
		svc_telegram: "Telegram",
		svc_caldav: "CalDAV",
		svc_webdav: "WebDAV",
		svc_rest: "Custom REST",
		theme: "Theme",
		themeLight: "Light",
		themeDark: "Dark",
		themeSystem: "System",
		language: "Language",
		notif: "Local notices",
		notifHint: "Bells, breaks, and due dates fire only while MetaShkola is open. Android background alarms are not part of this web build.",
		notifBrowser: "Allow browser notices",
		notifGranted: "The browser allowed notices",
		notifDenied: "The browser blocked notices",
		n_lessonStart: "Lesson starts",
		n_lessonEnd: "Lesson ends",
		n_breakStart: "Break starts",
		n_breakEnd: "Break ends",
		n_remind15: "15 minutes before",
		n_remind5: "5 minutes before",
		n_tasks: "Task due",
		n_personal: "Personal events",
		cloudNotif: "Cloud notices (server tasks, school announcements) are not delivered: the MetaShkola cloud is not deployed.",
		exportJson: "Download JSON",
		includeSecrets: "Include PIN and API keys",
		importJson: "Import JSON",
		replace: "Replace all",
		merge: "Merge by id",
		imported: "Import finished",
		reset: "Erase device data",
		resetConfirm: "Delete the local database and return to the start?",
		about: "About",
		aboutBody: "MetaShkola 2.0 is a modular learning environment. Concept author and creator: Andárer. Authorship does not depend on roles inside the app.",
		delivery: "This build is a working web app with a local database. A signed APK for the OPPO A74, the MetaShkola server, live OAuth, and Android background alarms are not implemented here and are not faked.",
		architecture: "What already works",
		archOk: "Local profiles and roles, family and school, a timetable of up to 12 lessons, bells, exceptions, tasks, marks, calendar, audit log, JSON, ICS, sync rules, MetaAI.",
		archNo: "Not in this delivery: cloud accounts and a multi-tenant server, push outside an open window, two-way Google and Microsoft sync, native Android.",
		audit: "Audit log",
		customRole: "Custom role",
		roleName: "Role name",
		reports: "Summary",
		openTasks: "Open tasks",
		avg: "Average mark",
		none: "None",
		namePh: "Name",
		askPh: "Ask in a way that still leaves the thinking to you",
		linkPh: "https://…",
		wd1: "Monday",
		wd2: "Tuesday",
		wd3: "Wednesday",
		wd4: "Thursday",
		wd5: "Friday",
		wd6: "Saturday",
		wd7: "Sunday",
		forWhom: "For",
		history: "History",
		preset: "Catalog",
		langAnswer: "Answer in English.",
		bellIn: "Bell in {t}",
		untilEnd: "{t} left",
		free: "Free",
		addSpace: "Another space",
		addSpaceLead: "Family, a personal day, and a school can live together on this device.",
		joinExisting: "Already in another space",
		joinLead: "They get a role here and keep every other one.",
		bySubject: "By subject",
		homeroomPick: "Homeroom teacher"
	}
};
function t(lang, key) {
	return dictionaries[lang][key] ?? ru[key];
}
function tf(lang, key, vars) {
	return t(lang, key).replace(/\{(\w+)\}/g, (_, name) => String(vars[name] ?? ""));
}
var ROLE_KEYS = [
	"creator",
	"sysadmin",
	"orgAdmin",
	"familyAdmin",
	"parent",
	"teacher",
	"homeroom",
	"student",
	"guest"
];
var ACTIONS = [
	"view",
	"create",
	"edit",
	"delete",
	"import",
	"export",
	"members",
	"roles",
	"schedule",
	"tasks",
	"grades",
	"integrations",
	"ai",
	"reports"
];
var defaultBell = () => ({
	firstStart: "08:00",
	lessonMinutes: 45,
	breakMinutes: 10,
	bigBreakMinutes: 20,
	bigBreakAfter: [3],
	lessonsPerDay: 6
});
var defaultNotif = () => ({
	lessonStart: true,
	lessonEnd: true,
	breakStart: true,
	breakEnd: true,
	remind15: true,
	remind5: true,
	tasks: true,
	personal: true
});
var ALL$1 = Object.fromEntries(ACTIONS.map((action) => [action, true]));
var NONE = Object.fromEntries(ACTIONS.map((action) => [action, false]));
function flags(partial) {
	return {
		...NONE,
		...partial
	};
}
var ROLE_GRANTS = {
	creator: ALL$1,
	sysadmin: ALL$1,
	orgAdmin: ALL$1,
	familyAdmin: ALL$1,
	parent: flags({
		view: true,
		create: true,
		export: true,
		ai: true,
		reports: true
	}),
	teacher: flags({
		view: true,
		create: true,
		edit: true,
		delete: true,
		export: true,
		schedule: true,
		tasks: true,
		grades: true,
		ai: true,
		reports: true
	}),
	homeroom: flags({
		view: true,
		create: true,
		edit: true,
		delete: true,
		export: true,
		members: true,
		schedule: true,
		tasks: true,
		grades: true,
		ai: true,
		reports: true
	}),
	student: flags({
		view: true,
		ai: true
	}),
	guest: flags({ view: true })
};
function isRoleKey(value) {
	return ROLE_KEYS.includes(value);
}
function grantsFor(roleKeys, customRoles, overrides) {
	const acc = { ...NONE };
	for (const key of roleKeys) {
		const source = isRoleKey(key) ? ROLE_GRANTS[key] : customRoles.find((role) => role.id === key)?.grants;
		if (!source) continue;
		for (const action of ACTIONS) if (source[action]) acc[action] = true;
	}
	if (overrides) {
		for (const action of ACTIONS) if (overrides[action] !== void 0) acc[action] = Boolean(overrides[action]);
	}
	return acc;
}
function membershipOf(profile, spaceId) {
	return profile?.memberships.find((item) => item.spaceId === spaceId);
}
function canInSpace(profile, spaceId, action, customRoles) {
	const membership = membershipOf(profile, spaceId);
	if (!membership) return false;
	return grantsFor(membership.roleKeys, customRoles, membership.grants)[action];
}
function isAdmin(membership) {
	if (!membership) return false;
	return membership.roleKeys.some((key) => key === "creator" || key === "sysadmin" || key === "orgAdmin" || key === "familyAdmin");
}
function canSeeTask(data, profile, task) {
	const membership = membershipOf(profile, task.spaceId);
	if (!profile || !membership) return false;
	if (!grantsFor(membership.roleKeys, data.customRoles, membership.grants).view) return false;
	if (isAdmin(membership) || membership.roleKeys.includes("teacher") || membership.roleKeys.includes("homeroom")) return true;
	if (task.assigneeId === profile.id) return true;
	return Boolean(membership.childIds?.includes(task.assigneeId));
}
function canSeeGrade(data, profile, grade) {
	const membership = membershipOf(profile, grade.spaceId);
	if (!profile || !membership) return false;
	if (membership.roleKeys.includes("guest")) return false;
	if (!grantsFor(membership.roleKeys, data.customRoles, membership.grants).view) return false;
	if (isAdmin(membership) || membership.roleKeys.includes("teacher") || membership.roleKeys.includes("homeroom")) return true;
	if (grade.studentId === profile.id) return true;
	return Boolean(membership.childIds?.includes(grade.studentId));
}
function canSeeEvent(data, profile, event) {
	const membership = membershipOf(profile, event.spaceId);
	if (!profile || !membership) return false;
	if (!grantsFor(membership.roleKeys, data.customRoles, membership.grants).view) return false;
	if (isAdmin(membership)) return true;
	if (event.profileId) {
		if (event.profileId === profile.id) return true;
		return Boolean(membership.childIds?.includes(event.profileId));
	}
	if (event.classId) {
		if (membership.classId === event.classId) return true;
		if (membership.roleKeys.includes("teacher") || membership.roleKeys.includes("homeroom")) return true;
		return (membership.childIds ?? []).some((childId) => data.profiles.some((child) => child.id === childId && child.memberships.some((item) => item.classId === event.classId)));
	}
	return !membership.roleKeys.includes("guest") || event.kind !== "personal";
}
function aiAllowed(data, profile, spaceId) {
	if (!profile) return false;
	if (!canInSpace(profile, spaceId, "ai", data.customRoles)) return false;
	const space = data.spaces.find((item) => item.id === spaceId);
	const membership = membershipOf(profile, spaceId);
	if (space?.aiRestrictedForMinors && membership?.roleKeys.includes("student")) return false;
	return true;
}
function canCreateSpace(profile, kind) {
	if (!profile) return false;
	const admin = Boolean(profile.isProjectCreator) || profile.memberships.some((membership) => membership.roleKeys.some((key) => key === "creator" || key === "sysadmin" || key === "orgAdmin" || key === "familyAdmin"));
	if (kind !== "personal") return admin;
	return admin || profile.memberships.some((membership) => membership.roleKeys.some((key) => key !== "guest"));
}
function blankGrants() {
	return { ...NONE };
}
function parseHHMM(value) {
	const [h, m] = value.split(":").map((n) => Number(n));
	if (!Number.isFinite(h) || !Number.isFinite(m)) return 480;
	return h * 60 + m;
}
function formatHHMM(mins) {
	const wrapped = (mins % 1440 + 1440) % 1440;
	const h = Math.floor(wrapped / 60);
	const m = wrapped % 60;
	return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
}
function lessonBounds(bell, index) {
	let cursor = parseHHMM(bell.firstStart);
	const safeIndex = Math.min(12, Math.max(1, index));
	for (let i = 1; i < safeIndex; i += 1) {
		cursor += bell.lessonMinutes;
		cursor += bell.bigBreakAfter.includes(i) ? bell.bigBreakMinutes : bell.breakMinutes;
	}
	return {
		startMin: cursor,
		endMin: cursor + bell.lessonMinutes
	};
}
function isoWeekday(date) {
	const n = date.getDay();
	return n === 0 ? 7 : n;
}
function startOfDay(date) {
	const next = new Date(date);
	next.setHours(0, 0, 0, 0);
	return next;
}
function addDays(date, days) {
	const next = startOfDay(date);
	next.setDate(next.getDate() + days);
	return next;
}
function toISODate(date) {
	return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}
function fromISODate(iso) {
	const [y, m, d] = iso.split("-").map((n) => Number(n));
	return new Date(y, (m || 1) - 1, d || 1);
}
function minutesNow(date = /* @__PURE__ */ new Date()) {
	return date.getHours() * 60 + date.getMinutes();
}
function resolveDay(bell, lessons, exceptions, dateISO, weekday, filter) {
	return lessons.filter((lesson) => {
		if (lesson.weekday !== weekday) return false;
		if (filter.teacherId) return lesson.teacherId === filter.teacherId;
		if (filter.ownerProfileId) return lesson.ownerProfileId === filter.ownerProfileId && !lesson.classId;
		if (filter.classId) return lesson.classId === filter.classId;
		return false;
	}).slice().sort((a, b) => a.index - b.index).map((lesson) => {
		const bounds = lessonBounds(bell, lesson.index);
		const exception = exceptions.find((item) => item.date === dateISO && item.lessonIndex === lesson.index && item.spaceId === lesson.spaceId && item.classId === lesson.classId);
		if (!exception) return {
			lesson,
			...bounds,
			subjectId: lesson.subjectId,
			teacherId: lesson.teacherId,
			room: lesson.room,
			cancelled: false
		};
		if (exception.kind === "cancel") return {
			lesson,
			...bounds,
			subjectId: lesson.subjectId,
			teacherId: lesson.teacherId,
			room: lesson.room,
			cancelled: true,
			note: exception.note
		};
		return {
			lesson,
			...bounds,
			subjectId: exception.subjectId || lesson.subjectId,
			teacherId: exception.teacherId === void 0 ? lesson.teacherId : exception.teacherId,
			room: exception.room || lesson.room,
			cancelled: false,
			note: exception.note
		};
	});
}
function dayPhase(rows, nowMin) {
	const active = rows.filter((row) => !row.cancelled);
	if (active.length === 0) return { kind: "empty" };
	const first = active[0];
	if (!first) return { kind: "empty" };
	if (nowMin < first.startMin) return {
		kind: "before",
		next: first,
		mins: first.startMin - nowMin
	};
	for (let i = 0; i < active.length; i += 1) {
		const row = active[i];
		if (!row) continue;
		if (nowMin >= row.startMin && nowMin < row.endMin) return {
			kind: "lesson",
			current: row,
			mins: row.endMin - nowMin
		};
		const next = active[i + 1];
		if (nowMin >= row.endMin && next && nowMin < next.startMin) return {
			kind: "break",
			prev: row,
			next,
			mins: next.startMin - nowMin
		};
	}
	return {
		kind: "after",
		prev: active[active.length - 1]
	};
}
function formatCountdown(mins) {
	const safe = Math.max(0, mins);
	const h = Math.floor(safe / 60);
	const m = safe % 60;
	if (h <= 0) return String(m);
	return `${h}:${String(m).padStart(2, "0")}`;
}
var FAMILY = "sp-family";
var SCHOOL = "sp-school";
var ORG = "org-lyceum";
var DIV = "div-mid";
var C7 = "c-7a";
var C4 = "c-4b";
var OLENA = "p-olena";
var MARKO = "p-marko";
var SOFIA = "p-sofia";
var ANDRIY = "p-andriy";
var GUEST = "p-guest";
var SUB = {
	math: "sub-math",
	ukr: "sub-ukr",
	eng: "sub-eng",
	hist: "sub-hist",
	phys: "sub-phys",
	pe: "sub-pe",
	bio: "sub-bio"
};
function iso(offset) {
	return toISODate(addDays(/* @__PURE__ */ new Date(), offset));
}
function lessonsFor(classId, pattern) {
	const rows = [];
	for (const [day, slots] of Object.entries(pattern)) slots.forEach((slot, index) => {
		rows.push({
			id: uid(),
			spaceId: SCHOOL,
			classId,
			ownerProfileId: null,
			weekday: Number(day),
			index: index + 1,
			subjectId: slot[0],
			room: slot[1],
			teacherId: slot[2]
		});
	});
	return rows;
}
var assistants = () => [
	{
		id: "ai-tutor",
		builtin: true,
		name: "AI-Репетитор",
		instruction: "Ты учебный репетитор MetaШколы. Объясняй коротко, по шагам, с проверкой понимания. Не выдавай готовое решение целиком: сначала наводящий вопрос, затем подсказка, и только если ученик просит — разбор одного похожего примера."
	},
	{
		id: "ai-math",
		builtin: true,
		name: "AI-Математик",
		instruction: "Ты помощник по математике. Веди ученика по решению, проси следующий шаг, указывай на ошибку, не подменяй самостоятельную работу."
	},
	{
		id: "ai-lang",
		builtin: true,
		name: "AI-Языковой помощник",
		instruction: "Ты языковой помощник. Исправляй формулировки бережно, объясняй правило и давай короткую тренировку."
	},
	{
		id: "ai-hw",
		builtin: true,
		name: "AI-Помощник по заданиям",
		instruction: "Помогай понять домашнее задание. Не пиши работу за ученика. Уточни, что уже сделано, и предложи следующий самостоятельный шаг."
	},
	{
		id: "ai-plan",
		builtin: true,
		name: "AI-Планировщик",
		instruction: "Помоги разложить учёбу по времени. Учитывай сроки, приоритет и отдых. Предлагай реалистичный план на день."
	},
	{
		id: "ai-teacher",
		builtin: true,
		name: "AI-Ассистент преподавателя",
		instruction: "Помогай преподавателю: формулировки заданий, критерии, идеи объяснения. Не выдумывай факты об учениках, которых нет в сообщении."
	},
	{
		id: "ai-parent",
		builtin: true,
		name: "AI-Ассистент родителя",
		instruction: "Помогай родителю спокойно разобраться в учёбе ребёнка: что спросить, как поддержать, без давления и без выполнения задания вместо ребёнка."
	}
];
function demoData() {
	const week = [
		1,
		2,
		3,
		4,
		5
	];
	const seven = {};
	const four = {};
	for (const day of week) {
		const mathRoom = day % 2 === 0 ? "21" : "22";
		seven[day] = [
			[
				SUB.math,
				mathRoom,
				ANDRIY
			],
			[
				SUB.ukr,
				"21",
				null
			],
			[
				day === 3 ? SUB.bio : SUB.eng,
				day === 3 ? "14" : "12",
				null
			],
			[
				SUB.hist,
				"21",
				null
			],
			[
				day === 5 ? SUB.bio : SUB.phys,
				day === 5 ? "14" : "30",
				null
			],
			[
				SUB.pe,
				"Спортзал",
				null
			]
		];
		four[day] = [
			[
				SUB.ukr,
				"8",
				null
			],
			[
				SUB.math,
				"8",
				ANDRIY
			],
			[
				SUB.eng,
				"12",
				null
			],
			[
				SUB.bio,
				"14",
				null
			],
			[
				SUB.pe,
				"Спортзал",
				null
			]
		];
	}
	return {
		version: 1,
		lang: "ru",
		theme: "system",
		activeProfileId: OLENA,
		activeSpaceId: FAMILY,
		profiles: [
			{
				id: OLENA,
				name: "Олена Коваленко",
				tone: "copper",
				isProjectCreator: true,
				memberships: [{
					spaceId: FAMILY,
					roleKeys: [
						"creator",
						"familyAdmin",
						"parent"
					],
					childIds: [MARKO, SOFIA]
				}, {
					spaceId: SCHOOL,
					roleKeys: ["creator", "parent"],
					childIds: [MARKO, SOFIA]
				}]
			},
			{
				id: MARKO,
				name: "Марко Коваленко",
				tone: "sage",
				memberships: [{
					spaceId: FAMILY,
					roleKeys: ["student"]
				}, {
					spaceId: SCHOOL,
					roleKeys: ["student"],
					classId: C7
				}]
			},
			{
				id: SOFIA,
				name: "София Коваленко",
				tone: "clay",
				memberships: [{
					spaceId: FAMILY,
					roleKeys: ["student"]
				}, {
					spaceId: SCHOOL,
					roleKeys: ["student"],
					classId: C4
				}]
			},
			{
				id: ANDRIY,
				name: "Андрей Мельник",
				tone: "ink",
				memberships: [{
					spaceId: SCHOOL,
					roleKeys: ["teacher", "homeroom"],
					classId: C7
				}]
			},
			{
				id: GUEST,
				name: "Гость",
				tone: "ink",
				memberships: [{
					spaceId: SCHOOL,
					roleKeys: ["guest"]
				}]
			}
		],
		spaces: [{
			id: FAMILY,
			kind: "family",
			name: "Родина Коваленко",
			aiRestrictedForMinors: false,
			bell: defaultBell()
		}, {
			id: SCHOOL,
			kind: "school",
			name: "Лицей «Горизонт»",
			aiRestrictedForMinors: false,
			bell: defaultBell()
		}],
		orgs: [{
			id: ORG,
			spaceId: SCHOOL,
			name: "Лицей «Горизонт»"
		}],
		divisions: [{
			id: DIV,
			orgId: ORG,
			name: "Средняя школа"
		}],
		classes: [{
			id: C7,
			spaceId: SCHOOL,
			orgId: ORG,
			divisionId: DIV,
			name: "7-А",
			homeroomTeacherId: ANDRIY
		}, {
			id: C4,
			spaceId: SCHOOL,
			orgId: ORG,
			divisionId: DIV,
			name: "4-Б"
		}],
		groups: [{
			id: uid(),
			classId: C7,
			name: "Математика 7-А",
			subjectId: SUB.math,
			studentIds: [MARKO]
		}, {
			id: uid(),
			classId: C4,
			name: "Математика 4-Б",
			subjectId: SUB.math,
			studentIds: [SOFIA]
		}],
		subjects: [
			{
				id: SUB.math,
				spaceId: SCHOOL,
				name: "Математика",
				tone: "copper"
			},
			{
				id: SUB.ukr,
				spaceId: SCHOOL,
				name: "Украинский язык",
				tone: "sage"
			},
			{
				id: SUB.eng,
				spaceId: SCHOOL,
				name: "Английский язык",
				tone: "ink"
			},
			{
				id: SUB.hist,
				spaceId: SCHOOL,
				name: "История",
				tone: "clay"
			},
			{
				id: SUB.phys,
				spaceId: SCHOOL,
				name: "Физика",
				tone: "copper"
			},
			{
				id: SUB.bio,
				spaceId: SCHOOL,
				name: "Биология",
				tone: "sage"
			},
			{
				id: SUB.pe,
				spaceId: SCHOOL,
				name: "Физкультура",
				tone: "ink"
			}
		],
		periods: [{
			id: uid(),
			orgId: ORG,
			name: "I семестр",
			start: iso(-30),
			end: iso(60)
		}],
		lessons: [...lessonsFor(C7, seven), ...lessonsFor(C4, four)],
		exceptions: [{
			id: uid(),
			spaceId: SCHOOL,
			classId: C7,
			date: iso(1),
			lessonIndex: 6,
			kind: "cancel",
			note: "Спортзал занят"
		}],
		tasks: [
			{
				id: uid(),
				spaceId: SCHOOL,
				assigneeId: MARKO,
				classId: C7,
				subjectId: SUB.math,
				title: "Уравнения, №142–146",
				detail: "Показать проверку подстановкой хотя бы в двух номерах.",
				due: iso(1),
				priority: "high",
				status: "assigned",
				teacherId: ANDRIY,
				comments: [],
				attachments: [],
				history: [{
					at: (/* @__PURE__ */ new Date()).toISOString(),
					text: "Задание создано"
				}]
			},
			{
				id: uid(),
				spaceId: SCHOOL,
				assigneeId: MARKO,
				classId: C7,
				subjectId: SUB.eng,
				title: "Текст о любимом городе, 80–100 слов",
				detail: "Время Present Simple. Три абзаца: место, люди, чем заняться.",
				due: iso(3),
				priority: "normal",
				status: "progress",
				comments: [{
					id: uid(),
					authorId: MARKO,
					text: "Набросал первый абзац про набережную.",
					at: (/* @__PURE__ */ new Date()).toISOString()
				}],
				attachments: [],
				history: []
			},
			{
				id: uid(),
				spaceId: SCHOOL,
				assigneeId: SOFIA,
				classId: C4,
				subjectId: SUB.ukr,
				title: "Прочитать рассказ и выписать 5 слов",
				detail: "Слова записать с ударением.",
				due: iso(0),
				priority: "normal",
				status: "done",
				comments: [],
				attachments: [],
				history: []
			}
		],
		grades: [
			{
				id: uid(),
				spaceId: SCHOOL,
				studentId: MARKO,
				subjectId: SUB.math,
				teacherId: ANDRIY,
				score: 10,
				kind: "mark",
				date: iso(-5),
				comment: "Уверенно решает линейные уравнения"
			},
			{
				id: uid(),
				spaceId: SCHOOL,
				studentId: MARKO,
				subjectId: SUB.math,
				teacherId: ANDRIY,
				score: 8,
				kind: "test",
				date: iso(-12),
				comment: "Контрольная: ошибка в знаке"
			},
			{
				id: uid(),
				spaceId: SCHOOL,
				studentId: SOFIA,
				subjectId: SUB.math,
				teacherId: ANDRIY,
				score: 11,
				kind: "mark",
				date: iso(-3),
				comment: ""
			}
		],
		events: [
			{
				id: uid(),
				spaceId: SCHOOL,
				title: "Контрольная по математике, 7-А",
				date: iso(2),
				kind: "test",
				classId: C7,
				note: "Темы: уравнения и пропорции"
			},
			{
				id: uid(),
				spaceId: SCHOOL,
				title: "Родительское собрание 7-А",
				date: iso(6),
				kind: "meeting",
				classId: C7,
				note: "Кабинет 21, 18:00"
			},
			{
				id: uid(),
				spaceId: FAMILY,
				title: "Семейный выходной",
				date: iso(0),
				kind: "personal",
				note: "Без кружков"
			},
			{
				id: uid(),
				spaceId: SCHOOL,
				title: "Осенние каникулы",
				date: iso(20),
				endDate: iso(27),
				kind: "vacation",
				note: ""
			}
		],
		providers: [{
			id: "builtin-grok",
			name: "xAI Grok",
			kind: "builtin",
			baseUrl: "https://api.x.ai/v1",
			model: "grok-4.5",
			temperature: .4,
			enabled: true
		}],
		assistants: assistants(),
		chats: [],
		activeChatId: null,
		usage: [],
		integrations: [],
		rules: [],
		syncLog: [],
		inbox: [],
		notif: defaultNotif(),
		customRoles: [],
		audit: [{
			id: uid(),
			at: (/* @__PURE__ */ new Date()).toISOString(),
			profileId: OLENA,
			text: "Открыт демонстрационный контур лицея и семьи"
		}]
	};
}
function emptyData(input) {
	const profileId = uid();
	const spaceId = uid();
	const roles = input.kind === "school" ? ["creator", "orgAdmin"] : input.kind === "family" ? ["creator", "familyAdmin"] : ["creator"];
	const orgId = input.kind === "school" ? uid() : "";
	return {
		version: 1,
		lang: input.lang,
		theme: "system",
		activeProfileId: profileId,
		activeSpaceId: spaceId,
		profiles: [{
			id: profileId,
			name: input.name.trim() || "Пользователь",
			tone: "copper",
			isProjectCreator: true,
			memberships: [{
				spaceId,
				roleKeys: roles
			}]
		}],
		spaces: [{
			id: spaceId,
			kind: input.kind,
			name: input.spaceName.trim() || input.name,
			aiRestrictedForMinors: false,
			bell: defaultBell()
		}],
		orgs: input.kind === "school" ? [{
			id: orgId,
			spaceId,
			name: input.spaceName.trim() || input.name
		}] : [],
		divisions: [],
		classes: [],
		groups: [],
		subjects: [],
		periods: [],
		lessons: [],
		exceptions: [],
		tasks: [],
		grades: [],
		events: [],
		providers: [{
			id: "builtin-grok",
			name: "xAI Grok",
			kind: "builtin",
			baseUrl: "https://api.x.ai/v1",
			model: "grok-4.5",
			temperature: .4,
			enabled: true
		}],
		assistants: assistants(),
		chats: [],
		activeChatId: null,
		usage: [],
		integrations: [],
		rules: [],
		syncLog: [],
		inbox: [],
		notif: defaultNotif(),
		customRoles: [],
		audit: [{
			id: uid(),
			at: (/* @__PURE__ */ new Date()).toISOString(),
			profileId,
			text: "Создано локальное пространство"
		}]
	};
}
function shellData() {
	return {
		version: 1,
		lang: "ru",
		theme: "system",
		activeProfileId: "",
		activeSpaceId: "",
		profiles: [],
		spaces: [],
		orgs: [],
		divisions: [],
		classes: [],
		groups: [],
		subjects: [],
		periods: [],
		lessons: [],
		exceptions: [],
		tasks: [],
		grades: [],
		events: [],
		providers: [],
		assistants: [],
		chats: [],
		activeChatId: null,
		usage: [],
		integrations: [],
		rules: [],
		syncLog: [],
		inbox: [],
		notif: defaultNotif(),
		customRoles: [],
		audit: []
	};
}
function withAudit(data, text) {
	const entry = {
		id: uid(),
		at: (/* @__PURE__ */ new Date()).toISOString(),
		profileId: data.activeProfileId,
		text
	};
	return {
		...data,
		audit: [entry, ...data.audit].slice(0, 200)
	};
}
function upsert(list, item) {
	const index = list.findIndex((row) => row.id === item.id);
	if (index === -1) return [item, ...list];
	const next = list.slice();
	next[index] = item;
	return next;
}
function isData(value) {
	if (!value || typeof value !== "object") return false;
	const row = value;
	return row.version === 1 && Array.isArray(row.profiles) && Array.isArray(row.spaces);
}
var seenInbox = /* @__PURE__ */ new Set();
var useMs = create()(persist((set, get) => ({
	bootstrapped: false,
	data: shellData(),
	openDemo: () => set({
		bootstrapped: true,
		data: demoData()
	}),
	openEmpty: (input) => set({
		bootstrapped: true,
		data: emptyData(input)
	}),
	setLang: (lang) => set((s) => ({ data: {
		...s.data,
		lang
	} })),
	setTheme: (theme) => set((s) => ({ data: {
		...s.data,
		theme
	} })),
	setActiveProfile: (id) => set((s) => {
		const profile = s.data.profiles.find((item) => item.id === id);
		if (!profile) return s;
		const activeSpaceId = profile.memberships.some((item) => item.spaceId === s.data.activeSpaceId) ? s.data.activeSpaceId : profile.memberships[0]?.spaceId ?? s.data.activeSpaceId;
		return { data: withAudit({
			...s.data,
			activeProfileId: id,
			activeSpaceId
		}, `Профиль: ${profile.name}`) };
	}),
	setActiveSpace: (id) => set((s) => {
		const profile = s.data.profiles.find((item) => item.id === s.data.activeProfileId);
		if (profile && !profile.memberships.some((item) => item.spaceId === id)) return s;
		return { data: {
			...s.data,
			activeSpaceId: id
		} };
	}),
	setPin: (profileId, pin) => set((s) => ({ data: withAudit({
		...s.data,
		profiles: s.data.profiles.map((item) => item.id === profileId ? {
			...item,
			pin: pin || void 0
		} : item)
	}, pin ? "PIN профиля обновлён" : "PIN профиля снят") })),
	saveProfile: (profile) => set((s) => ({ data: withAudit({
		...s.data,
		profiles: upsert(s.data.profiles, profile)
	}, `Профиль сохранён: ${profile.name}`) })),
	removeProfile: (id) => set((s) => {
		const profile = s.data.profiles.find((item) => item.id === id);
		if (!profile || profile.isProjectCreator) return s;
		const profiles = s.data.profiles.filter((item) => item.id !== id);
		const activeProfileId = s.data.activeProfileId === id ? profiles[0]?.id ?? "" : s.data.activeProfileId;
		return { data: withAudit({
			...s.data,
			profiles,
			activeProfileId
		}, `Профиль удалён: ${profile.name}`) };
	}),
	saveSpace: (space) => set((s) => ({ data: withAudit({
		...s.data,
		spaces: upsert(s.data.spaces, space)
	}, `Пространство: ${space.name}`) })),
	createSpace: (input) => set((s) => {
		const profile = s.data.profiles.find((item) => item.id === s.data.activeProfileId);
		if (!profile || !canCreateSpace(profile, input.kind)) return s;
		const spaceId = uid();
		const name = input.name.trim() || "Пространство";
		const roleKeys = /* @__PURE__ */ new Set();
		if (profile.isProjectCreator) roleKeys.add("creator");
		if (input.kind === "school") roleKeys.add("orgAdmin");
		else if (input.kind === "family") {
			roleKeys.add("familyAdmin");
			roleKeys.add("parent");
		} else roleKeys.add("teacher");
		const space = {
			id: spaceId,
			kind: input.kind,
			name,
			aiRestrictedForMinors: false,
			bell: defaultBell()
		};
		return { data: withAudit({
			...s.data,
			activeSpaceId: spaceId,
			spaces: [space, ...s.data.spaces],
			orgs: input.kind === "school" ? [{
				id: uid(),
				spaceId,
				name
			}, ...s.data.orgs] : s.data.orgs,
			profiles: s.data.profiles.map((item) => item.id === profile.id ? {
				...item,
				memberships: [...item.memberships, {
					spaceId,
					roleKeys: [...roleKeys]
				}]
			} : item)
		}, `Пространство создано: ${name}`) };
	}),
	joinProfile: (profileId, roleKeys, classId) => set((s) => {
		const actor = s.data.profiles.find((item) => item.id === s.data.activeProfileId);
		const target = s.data.profiles.find((item) => item.id === profileId);
		if (!actor || !target || !canInSpace(actor, s.data.activeSpaceId, "members", s.data.customRoles)) return s;
		if (target.memberships.some((item) => item.spaceId === s.data.activeSpaceId)) return s;
		const keys = roleKeys.filter(Boolean);
		if (keys.length === 0) return s;
		return { data: withAudit({
			...s.data,
			profiles: s.data.profiles.map((item) => item.id === profileId ? {
				...item,
				memberships: [...item.memberships, {
					spaceId: s.data.activeSpaceId,
					roleKeys: keys,
					classId: classId || void 0
				}]
			} : item)
		}, `В пространство добавлен: ${target.name}`) };
	}),
	updateBell: (spaceId, bell) => set((s) => ({ data: withAudit({
		...s.data,
		spaces: s.data.spaces.map((space) => space.id === spaceId ? {
			...space,
			bell
		} : space)
	}, "Расписание звонков обновлено") })),
	setMinorAi: (spaceId, restricted) => set((s) => ({ data: withAudit({
		...s.data,
		spaces: s.data.spaces.map((space) => space.id === spaceId ? {
			...space,
			aiRestrictedForMinors: restricted
		} : space)
	}, restricted ? "ИИ для учеников ограничен" : "Ограничение ИИ для учеников снято") })),
	saveOrgName: (orgId, name) => set((s) => ({ data: {
		...s.data,
		orgs: s.data.orgs.map((org) => org.id === orgId ? {
			...org,
			name
		} : org)
	} })),
	addDivision: (orgId, name) => set((s) => ({ data: withAudit({
		...s.data,
		divisions: [...s.data.divisions, {
			id: uid(),
			orgId,
			name
		}]
	}, `Подразделение: ${name}`) })),
	saveClass: (room) => set((s) => ({ data: withAudit({
		...s.data,
		classes: upsert(s.data.classes, room)
	}, `Класс: ${room.name}`) })),
	removeClass: (id) => set((s) => ({ data: withAudit({
		...s.data,
		classes: s.data.classes.filter((item) => item.id !== id),
		groups: s.data.groups.filter((item) => item.classId !== id),
		lessons: s.data.lessons.filter((item) => item.classId !== id)
	}, "Класс удалён") })),
	saveGroup: (group) => set((s) => ({ data: {
		...s.data,
		groups: upsert(s.data.groups, group)
	} })),
	removeGroup: (id) => set((s) => ({ data: {
		...s.data,
		groups: s.data.groups.filter((item) => item.id !== id)
	} })),
	saveSubject: (subject) => set((s) => ({ data: {
		...s.data,
		subjects: upsert(s.data.subjects, subject)
	} })),
	removeSubject: (id) => set((s) => ({ data: {
		...s.data,
		subjects: s.data.subjects.filter((item) => item.id !== id)
	} })),
	addPeriod: (orgId, name, start, end) => set((s) => ({ data: {
		...s.data,
		periods: [...s.data.periods, {
			id: uid(),
			orgId,
			name,
			start,
			end
		}]
	} })),
	saveLesson: (lesson) => set((s) => {
		const withoutClash = s.data.lessons.filter((item) => {
			if (item.id === lesson.id) return false;
			if (item.spaceId !== lesson.spaceId || item.weekday !== lesson.weekday || item.index !== lesson.index) return true;
			if (lesson.classId) return item.classId !== lesson.classId;
			return item.ownerProfileId !== lesson.ownerProfileId;
		});
		return { data: withAudit({
			...s.data,
			lessons: [...withoutClash, lesson]
		}, "Урок в расписании сохранён") };
	}),
	deleteLesson: (id) => set((s) => ({ data: {
		...s.data,
		lessons: s.data.lessons.filter((item) => item.id !== id)
	} })),
	copyDay: (from, weekdays) => set((s) => {
		const targets = weekdays.filter((day) => day !== from.weekday);
		const source = s.data.lessons.filter((item) => {
			if (item.weekday !== from.weekday || item.spaceId !== from.spaceId) return false;
			if (from.classId) return item.classId === from.classId;
			return item.ownerProfileId === from.ownerProfileId && !item.classId;
		});
		if (targets.length === 0 || source.length === 0) return s;
		let lessons = s.data.lessons.filter((item) => {
			if (!targets.includes(item.weekday) || item.spaceId !== from.spaceId) return true;
			if (from.classId) return item.classId !== from.classId;
			return !(item.ownerProfileId === from.ownerProfileId && !item.classId);
		});
		for (const day of targets) for (const lesson of source) lessons = [...lessons, {
			...lesson,
			id: uid(),
			weekday: day
		}];
		return { data: withAudit({
			...s.data,
			lessons
		}, "День расписания скопирован") };
	}),
	saveException: (item) => set((s) => ({ data: withAudit({
		...s.data,
		exceptions: upsert(s.data.exceptions, item)
	}, "Исключение в расписании") })),
	removeException: (id) => set((s) => ({ data: {
		...s.data,
		exceptions: s.data.exceptions.filter((item) => item.id !== id)
	} })),
	saveTask: (task) => set((s) => ({ data: withAudit({
		...s.data,
		tasks: upsert(s.data.tasks, task)
	}, `Задание: ${task.title}`) })),
	setTaskStatus: (id, status, actorId) => set((s) => ({ data: {
		...s.data,
		tasks: s.data.tasks.map((task) => task.id === id ? {
			...task,
			status,
			history: [{
				at: (/* @__PURE__ */ new Date()).toISOString(),
				text: `${actorId}:${status}`
			}, ...task.history].slice(0, 30)
		} : task)
	} })),
	addComment: (taskId, authorId, text) => set((s) => ({ data: {
		...s.data,
		tasks: s.data.tasks.map((task) => task.id === taskId ? {
			...task,
			comments: [...task.comments, {
				id: uid(),
				authorId,
				text,
				at: (/* @__PURE__ */ new Date()).toISOString()
			}]
		} : task)
	} })),
	removeTask: (id) => set((s) => ({ data: {
		...s.data,
		tasks: s.data.tasks.filter((item) => item.id !== id)
	} })),
	saveGrade: (grade) => set((s) => ({ data: withAudit({
		...s.data,
		grades: upsert(s.data.grades, grade)
	}, "Оценка сохранена") })),
	removeGrade: (id) => set((s) => ({ data: {
		...s.data,
		grades: s.data.grades.filter((item) => item.id !== id)
	} })),
	saveEvent: (event) => set((s) => ({ data: withAudit({
		...s.data,
		events: upsert(s.data.events, event)
	}, `Событие: ${event.title}`) })),
	removeEvent: (id) => set((s) => ({ data: {
		...s.data,
		events: s.data.events.filter((item) => item.id !== id)
	} })),
	saveProvider: (provider) => set((s) => ({ data: {
		...s.data,
		providers: upsert(s.data.providers, provider)
	} })),
	removeProvider: (id) => set((s) => ({ data: {
		...s.data,
		providers: s.data.providers.filter((item) => item.id !== id || item.kind === "builtin")
	} })),
	saveAssistant: (assistant) => set((s) => ({ data: {
		...s.data,
		assistants: upsert(s.data.assistants, assistant)
	} })),
	removeAssistant: (id) => set((s) => ({ data: {
		...s.data,
		assistants: s.data.assistants.filter((item) => item.id !== id || item.builtin)
	} })),
	startChat: (assistantId, providerId) => {
		const id = uid();
		const chat = {
			id,
			assistantId,
			providerId,
			title: get().data.assistants.find((item) => item.id === assistantId)?.name ?? "MetaAI",
			messages: []
		};
		set((s) => ({ data: {
			...s.data,
			chats: [chat, ...s.data.chats].slice(0, 40),
			activeChatId: id
		} }));
		return id;
	},
	appendChat: (chatId, message) => set((s) => ({ data: {
		...s.data,
		chats: s.data.chats.map((chat) => chat.id === chatId ? {
			...chat,
			messages: [...chat.messages, {
				id: uid(),
				at: (/* @__PURE__ */ new Date()).toISOString(),
				...message
			}].slice(-40)
		} : chat)
	} })),
	addUsage: (providerId, model, promptTokens, completionTokens) => set((s) => ({ data: {
		...s.data,
		usage: [{
			id: uid(),
			at: (/* @__PURE__ */ new Date()).toISOString(),
			providerId,
			model,
			promptTokens,
			completionTokens
		}, ...s.data.usage].slice(0, 100)
	} })),
	saveIntegration: (item) => set((s) => ({ data: {
		...s.data,
		integrations: upsert(s.data.integrations, item)
	} })),
	removeIntegration: (id) => set((s) => ({ data: {
		...s.data,
		integrations: s.data.integrations.filter((item) => item.id !== id),
		rules: s.data.rules.filter((rule) => rule.integrationId !== id)
	} })),
	saveRule: (rule) => set((s) => ({ data: {
		...s.data,
		rules: upsert(s.data.rules, rule)
	} })),
	removeRule: (id) => set((s) => ({ data: {
		...s.data,
		rules: s.data.rules.filter((item) => item.id !== id)
	} })),
	logSync: (text, ok, ruleId) => set((s) => ({ data: {
		...s.data,
		syncLog: [{
			id: uid(),
			at: (/* @__PURE__ */ new Date()).toISOString(),
			text,
			ok,
			ruleId
		}, ...s.data.syncLog].slice(0, 80)
	} })),
	pushInbox: (title, body, dedupeKey) => {
		if (seenInbox.has(dedupeKey)) return;
		if (get().data.inbox.some((item) => item.id === dedupeKey)) {
			seenInbox.add(dedupeKey);
			return;
		}
		seenInbox.add(dedupeKey);
		set((s) => ({ data: {
			...s.data,
			inbox: [{
				id: dedupeKey,
				at: (/* @__PURE__ */ new Date()).toISOString(),
				title,
				body,
				read: false
			}, ...s.data.inbox].slice(0, 60)
		} }));
	},
	markInboxRead: () => set((s) => ({ data: {
		...s.data,
		inbox: s.data.inbox.map((item) => ({
			...item,
			read: true
		}))
	} })),
	setNotif: (key, value) => set((s) => ({ data: {
		...s.data,
		notif: {
			...s.data.notif,
			[key]: value
		}
	} })),
	saveCustomRole: (role) => set((s) => ({ data: {
		...s.data,
		customRoles: upsert(s.data.customRoles, role)
	} })),
	removeCustomRole: (id) => set((s) => ({ data: {
		...s.data,
		customRoles: s.data.customRoles.filter((item) => item.id !== id)
	} })),
	importData: (raw, mode) => {
		if (!isData(raw)) return {
			ok: false,
			error: "format"
		};
		if (mode === "replace") {
			set({
				bootstrapped: true,
				data: raw
			});
			return { ok: true };
		}
		set((s) => ({
			bootstrapped: true,
			data: {
				...s.data,
				profiles: mergeById(s.data.profiles, raw.profiles),
				spaces: mergeById(s.data.spaces, raw.spaces),
				orgs: mergeById(s.data.orgs, raw.orgs),
				divisions: mergeById(s.data.divisions, raw.divisions),
				classes: mergeById(s.data.classes, raw.classes),
				groups: mergeById(s.data.groups, raw.groups),
				subjects: mergeById(s.data.subjects, raw.subjects),
				periods: mergeById(s.data.periods, raw.periods),
				lessons: mergeById(s.data.lessons, raw.lessons),
				exceptions: mergeById(s.data.exceptions, raw.exceptions),
				tasks: mergeById(s.data.tasks, raw.tasks),
				grades: mergeById(s.data.grades, raw.grades),
				events: mergeById(s.data.events, raw.events)
			}
		}));
		return { ok: true };
	},
	resetAll: () => set({
		bootstrapped: false,
		data: shellData()
	})
}), {
	name: "metashkola-db-v1",
	version: 1,
	skipHydration: true,
	partialize: (state) => ({
		bootstrapped: state.bootstrapped,
		data: state.data
	})
}));
function mergeById(current, incoming) {
	if (!incoming) return current;
	const map = new Map(current.map((item) => [item.id, item]));
	for (const item of incoming) map.set(item.id, item);
	return [...map.values()];
}
function redactSecrets(data, includeSecrets) {
	if (includeSecrets) return data;
	return {
		...data,
		profiles: data.profiles.map((profile) => ({
			...profile,
			pin: void 0
		})),
		providers: data.providers.map((provider) => ({
			...provider,
			apiKey: void 0
		}))
	};
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function Card({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: cn("rounded-2xl border border-line bg-surface p-4", className),
		children
	});
}
function Btn({ variant = "primary", className, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn("inline-flex h-11 items-center justify-center gap-2 rounded-xl px-4 text-sm font-semibold disabled:opacity-50", {
			primary: "bg-copper text-copper-fg",
			ghost: "bg-surface-2 text-fg",
			danger: "bg-clay text-bg"
		}[variant], className),
		...props
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "flex flex-col gap-1 text-sm text-muted",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), children]
	});
}
var controlClass = "h-11 w-full rounded-xl border border-line bg-bg px-3 text-base text-fg";
var areaClass = "min-h-24 w-full rounded-xl border border-line bg-bg px-3 py-2 text-base text-fg";
function Modal({ open, title, onClose, children }) {
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-40 flex items-end justify-center bg-ink/60 sm:items-center",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-label": title,
			className: "max-h-dvh w-full overflow-y-auto rounded-t-2xl border border-line bg-surface p-4 sm:max-w-lg sm:rounded-2xl",
			onClick: (event) => event.stopPropagation(),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl text-fg",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "h-11 rounded-xl px-3 text-sm text-muted",
					onClick: onClose,
					children: "×"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col gap-3",
				children
			})]
		})
	});
}
var toneBg = {
	copper: "bg-copper text-copper-fg",
	sage: "bg-sage text-bg",
	clay: "bg-clay text-bg",
	ink: "bg-fg text-bg"
};
function toneBorder(tone) {
	if (tone === "sage") return "border-l-sage";
	if (tone === "clay") return "border-l-clay";
	if (tone === "ink") return "border-l-fg";
	return "border-l-copper";
}
function Avatar({ name, tone }) {
	const letters = name.split(" ").slice(0, 2).map((part) => part[0] ?? "").join("").toUpperCase();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-sm font-semibold", toneBg[tone]),
		children: letters || "·"
	});
}
function personName(data, id) {
	if (!id) return "—";
	return data.profiles.find((item) => item.id === id)?.name ?? "—";
}
function subjectOf(data, id) {
	return data.subjects.find((item) => item.id === id);
}
function downloadText(filename, content, type) {
	const blob = new Blob([content], { type });
	const url = URL.createObjectURL(blob);
	const link = document.createElement("a");
	link.href = url;
	link.download = filename;
	link.click();
	URL.revokeObjectURL(url);
}
var PRESETS = [
	{
		name: "OpenAI",
		baseUrl: "https://api.openai.com/v1"
	},
	{
		name: "OpenRouter",
		baseUrl: "https://openrouter.ai/api/v1"
	},
	{
		name: "Google Gemini",
		baseUrl: "https://generativelanguage.googleapis.com/v1beta/openai"
	},
	{
		name: "DeepSeek",
		baseUrl: "https://api.deepseek.com/v1"
	},
	{
		name: "Mistral",
		baseUrl: "https://api.mistral.ai/v1"
	},
	{
		name: "xAI Grok",
		baseUrl: "https://api.x.ai/v1"
	}
];
function explain(lang, result) {
	if (result.ok) return "";
	if (result.error === "no_key") return t(lang, "err_no_key");
	if (result.error === "bad_url") return t(lang, "err_bad_url");
	if (result.error === "empty") return t(lang, "err_empty");
	if (result.error === "network") return t(lang, "err_network");
	return `${t(lang, "err_upstream")}${result.detail ? ` (${result.detail})` : ""}`;
}
function AiScreen() {
	const data = useMs((s) => s.data);
	const startChat = useMs((s) => s.startChat);
	const appendChat = useMs((s) => s.appendChat);
	const addUsage = useMs((s) => s.addUsage);
	const saveProvider = useMs((s) => s.saveProvider);
	const removeProvider = useMs((s) => s.removeProvider);
	const saveAssistant = useMs((s) => s.saveAssistant);
	const lang = data.lang;
	const profile = data.profiles.find((item) => item.id === data.activeProfileId);
	const allowed = aiAllowed(data, profile, data.activeSpaceId);
	const studentBlocked = Boolean(profile?.memberships.some((item) => item.spaceId === data.activeSpaceId && item.roleKeys.includes("student"))) && data.spaces.find((space) => space.id === data.activeSpaceId)?.aiRestrictedForMinors;
	const providers = data.providers.filter((item) => item.enabled);
	const [assistantId, setAssistantId] = (0, import_react.useState)(data.assistants[0]?.id ?? "");
	const [providerId, setProviderId] = (0, import_react.useState)(providers[0]?.id ?? "");
	const [secondId, setSecondId] = (0, import_react.useState)("");
	const [compare, setCompare] = (0, import_react.useState)(false);
	const [text, setText] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [probe, setProbe] = (0, import_react.useState)("");
	const [customName, setCustomName] = (0, import_react.useState)("");
	const [customPrompt, setCustomPrompt] = (0, import_react.useState)("");
	const [draft, setDraft] = (0, import_react.useState)({
		name: "OpenAI",
		baseUrl: "https://api.openai.com/v1",
		model: "gpt-4.1-mini",
		apiKey: "",
		temperature: .4
	});
	const chat = data.chats.find((item) => item.id === data.activeChatId) ?? null;
	if (!profile || !canInSpace(profile, data.activeSpaceId, "ai", data.customRoles)) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-3xl",
			children: t(lang, "ai")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: t(lang, "aiNoGrant")
		})]
	});
	if (!allowed || studentBlocked) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-3xl",
			children: t(lang, "ai")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: t(lang, "aiBlocked")
		})]
	});
	const ask = async (provider, prompt, history) => {
		const assistant = data.assistants.find((item) => item.id === assistantId);
		return await askTutor({ data: {
			mode: provider.kind === "builtin" ? "builtin" : "custom",
			baseUrl: provider.baseUrl,
			apiKey: provider.apiKey,
			model: provider.model,
			temperature: provider.temperature,
			messages: [
				{
					role: "system",
					content: `${assistant?.instruction ?? ""}\n${t(lang, "langAnswer")}`
				},
				...history.slice(-8),
				{
					role: "user",
					content: prompt
				}
			]
		} });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl",
				children: t(lang, "ai")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: t(lang, "aiLead")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "assistant"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: controlClass,
					value: assistantId,
					onChange: (event) => setAssistantId(event.target.value),
					children: data.assistants.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: item.id,
						children: item.name
					}, item.id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "model"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: controlClass,
					value: providerId,
					onChange: (event) => setProviderId(event.target.value),
					children: providers.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
						value: item.id,
						children: [
							item.name,
							" · ",
							item.model
						]
					}, item.id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex h-11 items-center gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: compare,
					onChange: (event) => setCompare(event.target.checked)
				}), t(lang, "compare")]
			}),
			compare ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "secondModel"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: controlClass,
					value: secondId,
					onChange: (event) => setSecondId(event.target.value),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "—"
					}), providers.filter((item) => item.id !== providerId).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
						value: item.id,
						children: [
							item.name,
							" · ",
							item.model
						]
					}, item.id))]
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex max-h-96 flex-col gap-3 overflow-y-auto",
				children: [
					chat?.messages.map((message) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: message.role === "user" ? "text-fg" : "text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-semibold",
							children: [message.role === "user" ? profile.name : message.providerId || "AI", ": "]
						}), message.content]
					}, message.id)),
					busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-copper",
						children: t(lang, "thinking")
					}) : null,
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-clay",
						children: error
					}) : null
				]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex flex-col gap-2",
				onSubmit: async (event) => {
					event.preventDefault();
					const prompt = text.trim();
					const provider = providers.find((item) => item.id === providerId);
					if (!prompt || !provider || busy) return;
					setBusy(true);
					setError("");
					const chatId = chat?.id ?? startChat(assistantId, provider.id);
					const history = (chat?.messages ?? []).map((message) => ({
						role: message.role,
						content: message.content
					}));
					appendChat(chatId, {
						role: "user",
						content: prompt
					});
					setText("");
					const first = await ask(provider, prompt, history);
					if (!first.ok) {
						setError(explain(lang, first));
						setBusy(false);
						return;
					}
					appendChat(chatId, {
						role: "assistant",
						content: first.text,
						providerId: provider.name
					});
					addUsage(provider.id, first.model, first.promptTokens, first.completionTokens);
					const second = providers.find((item) => item.id === secondId);
					if (compare && second) {
						const other = await ask(second, prompt, history);
						if (other.ok) {
							appendChat(chatId, {
								role: "assistant",
								content: other.text,
								providerId: second.name
							});
							addUsage(second.id, other.model, other.promptTokens, other.completionTokens);
						} else setError(explain(lang, other));
					}
					setBusy(false);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: areaClass,
					placeholder: t(lang, "askPh"),
					value: text,
					onChange: (event) => setText(event.target.value)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					type: "submit",
					disabled: busy || !text.trim(),
					children: t(lang, "send")
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-2xl",
				children: t(lang, "usage")
			}),
			data.usage.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: t(lang, "usageEmpty")
			}) : null,
			data.usage.slice(0, 8).map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					row.model,
					" · ",
					tf(lang, "tokens", {
						p: row.promptTokens,
						c: row.completionTokens
					})
				]
			}, row.id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-2xl",
				children: t(lang, "newAssistant")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "namePh"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: controlClass,
					value: customName,
					onChange: (event) => setCustomName(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "instruction"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: areaClass,
					value: customPrompt,
					onChange: (event) => setCustomPrompt(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				variant: "ghost",
				disabled: !customName.trim() || !customPrompt.trim(),
				onClick: () => {
					saveAssistant({
						id: uid(),
						name: customName.trim(),
						instruction: customPrompt.trim(),
						builtin: false
					});
					setCustomName("");
					setCustomPrompt("");
				},
				children: t(lang, "save")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-2xl",
				children: t(lang, "providers")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: t(lang, "catalogNote")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: PRESETS.map((preset) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "ghost",
					onClick: () => setDraft({
						...draft,
						name: preset.name,
						baseUrl: preset.baseUrl
					}),
					children: preset.name
				}, preset.name))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "namePh"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: controlClass,
					value: draft.name,
					onChange: (event) => setDraft({
						...draft,
						name: event.target.value
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "baseUrl"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: controlClass,
					value: draft.baseUrl,
					onChange: (event) => setDraft({
						...draft,
						baseUrl: event.target.value
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "model"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: controlClass,
					value: draft.model,
					onChange: (event) => setDraft({
						...draft,
						model: event.target.value
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "apiKey"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: controlClass,
					type: "password",
					autoComplete: "off",
					value: draft.apiKey,
					onChange: (event) => setDraft({
						...draft,
						apiKey: event.target.value
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "temperature"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: controlClass,
					type: "number",
					min: 0,
					max: 1,
					step: .1,
					value: draft.temperature,
					onChange: (event) => setDraft({
						...draft,
						temperature: Math.min(1, Math.max(0, Number(event.target.value) || 0))
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					onClick: () => {
						const id = uid();
						saveProvider({
							id,
							name: draft.name,
							kind: "openai",
							baseUrl: draft.baseUrl,
							model: draft.model,
							apiKey: draft.apiKey,
							temperature: draft.temperature,
							enabled: true
						});
						setProviderId(id);
					},
					disabled: !draft.apiKey || !draft.model,
					children: t(lang, "addProvider")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "ghost",
					onClick: async () => {
						const result = await probeModels({ data: draft.baseUrl.includes("api.x.ai") && !draft.apiKey ? { mode: "builtin" } : {
							mode: "custom",
							baseUrl: draft.baseUrl,
							apiKey: draft.apiKey
						} });
						setProbe(result.ok ? tf(lang, "probeOk", { n: result.models.length }) : explain(lang, {
							ok: false,
							error: result.error,
							detail: result.detail
						}));
					},
					children: t(lang, "probe")
				})]
			}),
			probe ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: probe
			}) : null,
			data.providers.map((provider) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-semibold",
					children: provider.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: provider.model
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: provider.kind === "builtin" ? t(lang, "builtinKey") : provider.baseUrl
				}),
				provider.kind !== "builtin" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "danger",
					className: "mt-2",
					onClick: () => removeProvider(provider.id),
					children: t(lang, "delete")
				}) : null
			] }, provider.id))
		]
	});
}
function watchGroups(data, profile) {
	if (!profile) return [];
	const groups = [];
	const push = (group) => {
		if (!groups.some((item) => item.id === group.id)) groups.push(group);
	};
	for (const membership of profile.memberships) {
		const roles = new Set(membership.roleKeys);
		if (membership.classId && (roles.has("student") || roles.has("homeroom"))) {
			const room = data.classes.find((item) => item.id === membership.classId);
			push({
				id: `class:${membership.classId}`,
				label: room?.name ?? membership.classId,
				spaceId: membership.spaceId,
				classId: membership.classId,
				ownerProfileId: null,
				teacherId: null
			});
		}
		if (roles.has("teacher") || roles.has("homeroom")) push({
			id: `teach:${profile.id}:${membership.spaceId}`,
			label: profile.name,
			spaceId: membership.spaceId,
			classId: null,
			ownerProfileId: null,
			teacherId: profile.id
		});
		if (roles.has("parent")) for (const childId of membership.childIds ?? []) {
			const child = data.profiles.find((item) => item.id === childId);
			const classMembership = child?.memberships.find((item) => item.classId);
			if (!classMembership?.classId) continue;
			data.classes.find((item) => item.id === classMembership.classId);
			push({
				id: `child:${childId}`,
				label: child?.name ?? childId,
				spaceId: classMembership.spaceId,
				classId: classMembership.classId,
				ownerProfileId: null,
				teacherId: null
			});
		}
	}
	if (groups.length === 0) for (const room of data.classes.filter((item) => item.spaceId === data.activeSpaceId)) push({
		id: `class:${room.id}`,
		label: room.name,
		spaceId: room.spaceId,
		classId: room.id,
		ownerProfileId: null,
		teacherId: null
	});
	if (data.lessons.some((lesson) => lesson.ownerProfileId === profile.id && !lesson.classId)) push({
		id: `me:${profile.id}`,
		label: profile.name,
		spaceId: data.activeSpaceId,
		classId: null,
		ownerProfileId: profile.id,
		teacherId: null
	});
	return groups;
}
function BellsScreen() {
	const data = useMs((s) => s.data);
	const lang = data.lang;
	const groups = watchGroups(data, data.profiles.find((item) => item.id === data.activeProfileId));
	const [groupId, setGroupId] = (0, import_react.useState)(groups[0]?.id ?? "");
	const [now, setNow] = (0, import_react.useState)(() => /* @__PURE__ */ new Date());
	(0, import_react.useEffect)(() => {
		const timer = window.setInterval(() => setNow(/* @__PURE__ */ new Date()), 1e3);
		return () => window.clearInterval(timer);
	}, []);
	const group = groups.find((item) => item.id === groupId) ?? groups[0];
	const space = data.spaces.find((item) => item.id === group?.spaceId);
	if (!group || !space) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: t(lang, "noLessons")
	});
	const date = toISODate(now);
	const rows = resolveDay(space.bell, data.lessons, data.exceptions, date, isoWeekday(now), {
		classId: group.teacherId ? void 0 : group.classId,
		ownerProfileId: group.ownerProfileId,
		teacherId: group.teacherId
	});
	const phase = dayPhase(rows, minutesNow(now));
	const clock = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}:${String(now.getSeconds()).padStart(2, "0")}`;
	let headline = t(lang, "phaseEmpty");
	let sub = "";
	if (phase.kind === "before") {
		headline = t(lang, "phaseBefore");
		sub = tf(lang, "bellIn", { t: formatCountdown(phase.mins) });
	} else if (phase.kind === "lesson") {
		headline = t(lang, "phaseLesson");
		sub = tf(lang, "untilEnd", { t: formatCountdown(phase.mins) });
	} else if (phase.kind === "break") {
		headline = t(lang, "phaseBreak");
		sub = tf(lang, "bellIn", { t: formatCountdown(phase.mins) });
	} else if (phase.kind === "after") headline = t(lang, "phaseAfter");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl",
				children: t(lang, "bells")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "myWatch"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: controlClass,
					value: group.id,
					onChange: (event) => setGroupId(event.target.value),
					children: groups.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: item.id,
						children: item.label
					}, item.id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-4xl tabular-nums",
					children: clock
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-lg font-semibold",
					children: headline
				}),
				sub ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-copper",
					children: sub
				}) : null
			] }),
			rows.map((row) => {
				const subject = subjectOf(data, row.subjectId);
				const current = phase.kind === "lesson" && phase.current.lesson.id === row.lesson.id;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cn("rounded-2xl border border-line bg-surface p-4 border-l-4", toneBorder(subject?.tone), row.cancelled && "opacity-50", current && "ring-2 ring-copper"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm tabular-nums text-muted",
							children: [
								formatHHMM(row.startMin),
								"–",
								formatHHMM(row.endMin)
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold",
							children: subject?.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: row.cancelled ? t(lang, "cancelled") : row.room
						})
					]
				}, row.lesson.id);
			})
		]
	});
}
var KINDS = [
	"study",
	"weekend",
	"vacation",
	"holiday",
	"test",
	"exam",
	"event",
	"personal",
	"meeting"
];
function kindKey(kind) {
	return `ev_${kind}`;
}
function CalendarScreen() {
	const data = useMs((s) => s.data);
	const saveEvent = useMs((s) => s.saveEvent);
	const removeEvent = useMs((s) => s.removeEvent);
	const lang = data.lang;
	const profile = data.profiles.find((item) => item.id === data.activeProfileId);
	const [cursor, setCursor] = (0, import_react.useState)(() => startOfDay(/* @__PURE__ */ new Date()));
	const [selected, setSelected] = (0, import_react.useState)(toISODate(/* @__PURE__ */ new Date()));
	const [open, setOpen] = (0, import_react.useState)(false);
	const canCreate = Boolean(profile && canInSpace(profile, data.activeSpaceId, "create", data.customRoles));
	const events = data.events.filter((event) => canSeeEvent(data, profile, event));
	const monthStart = new Date(cursor.getFullYear(), cursor.getMonth(), 1);
	const gridStart = addDays(monthStart, -(isoWeekday(monthStart) - 1));
	const days = (0, import_react.useMemo)(() => Array.from({ length: 42 }, (_, index) => addDays(gridStart, index)), [gridStart]);
	const selectedEvents = events.filter((event) => event.date <= selected && (event.endDate ?? event.date) >= selected);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-3xl",
					children: t(lang, "calendar")
				}), canCreate ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					onClick: () => setOpen(true),
					children: t(lang, "add")
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						variant: "ghost",
						onClick: () => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() - 1, 1)),
						children: "‹"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-semibold tabular-nums",
						children: [
							cursor.getFullYear(),
							"-",
							String(cursor.getMonth() + 1).padStart(2, "0")
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						variant: "ghost",
						onClick: () => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1)),
						children: "›"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-7 gap-1 text-center text-xs text-muted",
				children: [
					1,
					2,
					3,
					4,
					5,
					6,
					7
				].map((day) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, `wd${day}`).slice(0, 2) }, day))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-7 gap-1",
				children: days.map((day) => {
					const iso = toISODate(day);
					const inMonth = day.getMonth() === cursor.getMonth();
					const marked = events.some((event) => event.date <= iso && (event.endDate ?? event.date) >= iso);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: cn("h-11 rounded-xl text-sm tabular-nums", selected === iso ? "bg-copper text-copper-fg" : "bg-surface text-fg", !inMonth && "opacity-40"),
						onClick: () => setSelected(iso),
						children: [day.getDate(), marked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-0.5 block h-1 rounded-full bg-current" }) : null]
					}, iso);
				})
			}),
			selectedEvents.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: t(lang, "noEvents")
			}) : null,
			selectedEvents.map((event) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-copper",
					children: t(lang, kindKey(event.kind))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl",
					children: event.title
				}),
				event.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: event.note
				}) : null,
				canCreate && event.spaceId === data.activeSpaceId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "danger",
					className: "mt-2",
					onClick: () => removeEvent(event.id),
					children: t(lang, "delete")
				}) : null
			] }, event.id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EventComposer, {
				open,
				date: selected,
				onClose: () => setOpen(false),
				onSave: saveEvent
			})
		]
	});
}
function EventComposer({ open, date, onClose, onSave }) {
	const data = useMs((s) => s.data);
	const lang = data.lang;
	const [title, setTitle] = (0, import_react.useState)("");
	const [kind, setKind] = (0, import_react.useState)("personal");
	const [note, setNote] = (0, import_react.useState)("");
	const [endDate, setEndDate] = (0, import_react.useState)("");
	const [classId, setClassId] = (0, import_react.useState)("");
	if (!open) return null;
	const classes = data.classes.filter((item) => item.spaceId === data.activeSpaceId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
		open,
		title: t(lang, "newEvent"),
		onClose,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "title"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: controlClass,
					value: title,
					onChange: (event) => setTitle(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "kind"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: controlClass,
					value: kind,
					onChange: (event) => setKind(event.target.value),
					children: KINDS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: item,
						children: t(lang, kindKey(item))
					}, item))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "classLabel"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: controlClass,
					value: classId,
					onChange: (event) => setClassId(event.target.value),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: t(lang, "everyone")
					}), classes.map((room) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: room.id,
						children: room.name
					}, room.id))]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "date"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: controlClass,
					type: "date",
					value: endDate,
					onChange: (event) => setEndDate(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "note"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: controlClass,
					value: note,
					onChange: (event) => setNote(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				disabled: !title.trim(),
				onClick: () => {
					onSave({
						id: uid(),
						spaceId: data.activeSpaceId,
						title: title.trim(),
						date,
						endDate: endDate || void 0,
						kind,
						classId: classId || void 0,
						profileId: kind === "personal" ? data.activeProfileId : void 0,
						note
					});
					onClose();
				},
				children: t(lang, "save")
			})
		]
	});
}
var WEEK$1 = [
	"mon",
	"tue",
	"wed",
	"thu",
	"fri",
	"sat",
	"sun"
];
function dayLabel(lang, offsetLabel, date) {
	return `${t(lang, offsetLabel)} · ${t(lang, WEEK$1[isoWeekday(date) - 1] ?? "mon")}`;
}
function HomeScreen({ onOpen }) {
	const data = useMs((s) => s.data);
	const lang = data.lang;
	const profile = data.profiles.find((item) => item.id === data.activeProfileId);
	const groups = watchGroups(data, profile).slice(0, 3);
	const today = /* @__PURE__ */ new Date();
	const visibleTasks = data.tasks.filter((task) => canSeeTask(data, profile, task) && task.status !== "checked");
	const visibleGrades = data.grades.filter((grade) => canSeeGrade(data, profile, grade));
	const canReports = Boolean(profile && canInSpace(profile, data.activeSpaceId, "reports", data.customRoles));
	const subjectRows = Object.values(visibleGrades.reduce((acc, grade) => {
		const key = `${grade.studentId}:${grade.subjectId}`;
		const subject = subjectOf(data, grade.subjectId)?.name ?? t(lang, "subject");
		const who = personName(data, grade.studentId);
		const row = acc[key] ?? {
			id: key,
			label: `${who} · ${subject}`,
			sum: 0,
			count: 0
		};
		row.sum += grade.score;
		row.count += 1;
		acc[key] = row;
		return acc;
	}, {})).sort((a, b) => b.count - a.count);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl",
				children: profile?.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: data.spaces.find((space) => space.id === data.activeSpaceId)?.name
			})] }),
			groups.map((group) => {
				let when = today;
				let rows = [];
				for (let offset = 0; offset < 7; offset += 1) {
					const date = addDays(today, offset);
					const space = data.spaces.find((item) => item.id === group.spaceId);
					if (!space) break;
					const resolved = resolveDay(space.bell, data.lessons, data.exceptions, toISODate(date), isoWeekday(date), {
						classId: group.teacherId ? void 0 : group.classId,
						ownerProfileId: group.ownerProfileId,
						teacherId: group.teacherId
					}).filter((row) => !row.cancelled);
					if (resolved.length > 0) {
						when = date;
						rows = resolved;
						break;
					}
				}
				const label = toISODate(when) === toISODate(today) ? "today" : toISODate(when) === toISODate(addDays(today, 1)) ? "tomorrow" : "nextStudy";
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "flex w-full flex-col gap-3 text-left",
					onClick: () => onOpen("schedule"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-baseline justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-xl",
								children: group.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-muted",
								children: dayLabel(lang, label, when)
							})]
						}),
						rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: t(lang, "noLessons")
						}) : null,
						rows.slice(0, 4).map((row) => {
							const subject = subjectOf(data, row.subjectId);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: cn("border-l-4 pl-3", toneBorder(subject?.tone)),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-sm tabular-nums text-muted",
										children: [
											formatHHMM(row.startMin),
											"–",
											formatHHMM(row.endMin)
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-semibold",
										children: subject?.name ?? t(lang, "subject")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-sm text-muted",
										children: [
											row.room,
											" · ",
											personName(data, row.teacherId)
										]
									})
								]
							}, row.lesson.id);
						})
					]
				}) }, group.id);
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl",
						children: t(lang, "tasks")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "text-sm font-semibold text-copper",
						onClick: () => onOpen("tasks"),
						children: t(lang, "allTasks")
					})]
				}),
				visibleTasks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: t(lang, "noTasks")
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col gap-3",
					children: visibleTasks.slice().sort((a, b) => a.due.localeCompare(b.due)).slice(0, 3).map((task) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: task.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							personName(data, task.assigneeId),
							" · ",
							task.due,
							" · ",
							t(lang, `pr_${task.priority}`)
						]
					})] }, task.id))
				})
			] }),
			canReports ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl",
					children: t(lang, "reports")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm text-muted",
					children: [
						t(lang, "openTasks"),
						": ",
						visibleTasks.length
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-3 text-lg",
					children: t(lang, "bySubject")
				}),
				subjectRows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: t(lang, "none")
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-2 flex flex-col gap-2",
					children: subjectRows.slice(0, 8).map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-baseline justify-between gap-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "min-w-0 truncate",
							children: row.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-xl tabular-nums",
							children: Math.round(row.sum / row.count * 10) / 10
						})]
					}, row.id))
				})
			] }) : null
		]
	});
}
var SERVICES = [
	{
		id: "google-calendar",
		key: "svc_google_calendar"
	},
	{
		id: "google-drive",
		key: "svc_google_drive"
	},
	{
		id: "gmail",
		key: "svc_gmail"
	},
	{
		id: "classroom",
		key: "svc_classroom"
	},
	{
		id: "outlook",
		key: "svc_outlook"
	},
	{
		id: "onedrive",
		key: "svc_onedrive"
	},
	{
		id: "ms-calendar",
		key: "svc_ms_calendar"
	},
	{
		id: "telegram",
		key: "svc_telegram"
	},
	{
		id: "caldav",
		key: "svc_caldav"
	},
	{
		id: "webdav",
		key: "svc_webdav"
	},
	{
		id: "rest",
		key: "svc_rest"
	}
];
function icsStamp(iso) {
	return iso.replace(/-/g, "") + "T000000";
}
function IntegrationsScreen() {
	const data = useMs((s) => s.data);
	const saveIntegration = useMs((s) => s.saveIntegration);
	const removeIntegration = useMs((s) => s.removeIntegration);
	const saveRule = useMs((s) => s.saveRule);
	const removeRule = useMs((s) => s.removeRule);
	const logSync = useMs((s) => s.logSync);
	const lang = data.lang;
	const profile = data.profiles.find((item) => item.id === data.activeProfileId);
	const allowed = Boolean(profile && canInSpace(profile, data.activeSpaceId, "integrations", data.customRoles));
	const [service, setService] = (0, import_react.useState)("google-calendar");
	const [account, setAccount] = (0, import_react.useState)("");
	const [integrationId, setIntegrationId] = (0, import_react.useState)("");
	const [direction, setDirection] = (0, import_react.useState)("export");
	const [dataKind, setDataKind] = (0, import_react.useState)("calendar");
	const exportIcs = () => {
		const events = data.events.filter((event) => canSeeEvent(data, profile, event));
		const lines = [
			"BEGIN:VCALENDAR",
			"VERSION:2.0",
			"PRODID:-//MetaShkola//RU"
		];
		for (const event of events) lines.push("BEGIN:VEVENT", `UID:${event.id}@metashkola`, `DTSTART;VALUE=DATE:${icsStamp(event.date).slice(0, 8)}`, `SUMMARY:${event.title.replace(/[\n,;]/g, " ")}`, "END:VEVENT");
		lines.push("END:VCALENDAR");
		downloadText("metashkola.ics", lines.join("\r\n"), "text/calendar");
		logSync("ICS exported locally", true);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl",
				children: t(lang, "integrations")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: t(lang, "integrationsLead")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				variant: "ghost",
				onClick: exportIcs,
				children: t(lang, "exportIcs")
			}),
			allowed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex flex-col gap-3",
				onSubmit: (event) => {
					event.preventDefault();
					saveIntegration({
						id: uid(),
						service,
						label: t(lang, SERVICES.find((item) => item.id === service)?.key ?? "svc_rest"),
						accountLabel: account,
						enabled: true
					});
					setAccount("");
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: t(lang, "preset"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: controlClass,
							value: service,
							onChange: (event) => setService(event.target.value),
							children: SERVICES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: item.id,
								children: t(lang, item.key)
							}, item.id))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: t(lang, "accountLabel"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: controlClass,
							value: account,
							onChange: (event) => setAccount(event.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						type: "submit",
						children: t(lang, "add")
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: t(lang, "noAccess")
			}),
			data.integrations.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl",
					children: item.label
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: item.accountLabel || t(lang, "none")
				}),
				allowed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "danger",
					className: "mt-2",
					onClick: () => removeIntegration(item.id),
					children: t(lang, "delete")
				}) : null
			] }, item.id)),
			allowed && data.integrations.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex flex-col gap-3",
				onSubmit: (event) => {
					event.preventDefault();
					const id = integrationId || data.integrations[0]?.id;
					if (!id) return;
					saveRule({
						id: uid(),
						integrationId: id,
						direction,
						dataKind,
						frequency: "manual",
						profileId: "all",
						enabled: true
					});
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-2xl",
						children: t(lang, "enableRule")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: t(lang, "integrations"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: controlClass,
							value: integrationId || data.integrations[0]?.id,
							onChange: (event) => setIntegrationId(event.target.value),
							children: data.integrations.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: item.id,
								children: item.label
							}, item.id))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: t(lang, "direction"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: controlClass,
							value: direction,
							onChange: (event) => setDirection(event.target.value),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "import",
									children: t(lang, "dir_import")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "export",
									children: t(lang, "dir_export")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "both",
									children: t(lang, "dir_both")
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: t(lang, "dataKind"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: controlClass,
							value: dataKind,
							onChange: (event) => setDataKind(event.target.value),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "calendar",
									children: t(lang, "data_calendar")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "materials",
									children: t(lang, "data_materials")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "notifications",
									children: t(lang, "data_notifications")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "tasks",
									children: t(lang, "data_tasks")
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						type: "submit",
						children: t(lang, "save")
					})
				]
			}) : null,
			data.rules.map((rule) => {
				const integration = data.integrations.find((item) => item.id === rule.integrationId);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: integration?.label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							t(lang, `dir_${rule.direction}`),
							" · ",
							t(lang, `data_${rule.dataKind}`),
							" · ",
							t(lang, rule.frequency === "daily" ? "freq_daily" : "freq_manual")
						]
					}),
					allowed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							variant: "ghost",
							onClick: () => logSync(t(lang, "syncHonest"), false, rule.id),
							children: t(lang, "runSync")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							variant: "danger",
							onClick: () => removeRule(rule.id),
							children: t(lang, "delete")
						})]
					}) : null
				] }, rule.id);
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-2xl",
				children: t(lang, "journal")
			}),
			data.syncLog.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: t(lang, "journalEmpty")
			}) : null,
			data.syncLog.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					row.ok ? "OK" : "—",
					" · ",
					row.text
				]
			}, row.id))
		]
	});
}
function Notifier() {
	const data = useMs((s) => s.data);
	const pushInbox = useMs((s) => s.pushInbox);
	(0, import_react.useEffect)(() => {
		const tick = () => {
			const profile = data.profiles.find((item) => item.id === data.activeProfileId);
			if (!profile) return;
			const now = /* @__PURE__ */ new Date();
			const dateISO = toISODate(now);
			const nowMin = minutesNow(now);
			const prefs = data.notif;
			const lang = data.lang;
			for (const group of watchGroups(data, profile)) {
				const space = data.spaces.find((item) => item.id === group.spaceId);
				if (!space) continue;
				const rows = resolveDay(space.bell, data.lessons, data.exceptions, dateISO, now.getDay() === 0 ? 7 : now.getDay(), {
					classId: group.teacherId ? void 0 : group.classId,
					ownerProfileId: group.ownerProfileId,
					teacherId: group.teacherId
				});
				const phase = dayPhase(rows, nowMin);
				for (const row of rows) {
					if (row.cancelled) continue;
					const subject = subjectOf(data, row.subjectId)?.name ?? "";
					const until = row.startMin - nowMin;
					if (prefs.remind15 && until <= 15 && until > 5) pushInbox(t(lang, "n_remind15"), `${subject} · ${group.label}`, `${dateISO}|15|${group.id}|${row.lesson.index}`);
					if (prefs.remind5 && until <= 5 && until > 0) pushInbox(t(lang, "n_remind5"), `${subject} · ${group.label}`, `${dateISO}|5|${group.id}|${row.lesson.index}`);
				}
				if (phase.kind === "lesson" && prefs.lessonStart && nowMin - phase.current.startMin <= 1) {
					const subject = subjectOf(data, phase.current.subjectId)?.name ?? "";
					pushInbox(t(lang, "n_lessonStart"), subject, `${dateISO}|start|${group.id}|${phase.current.lesson.index}`);
					if (prefs.breakEnd) pushInbox(t(lang, "n_breakEnd"), subject, `${dateISO}|breakend|${group.id}|${phase.current.lesson.index}`);
				}
				if ((phase.kind === "break" || phase.kind === "after") && phase.prev && prefs.lessonEnd) {
					const left = nowMin - phase.prev.endMin;
					if (left >= 0 && left <= 1) {
						const subject = subjectOf(data, phase.prev.subjectId)?.name ?? "";
						pushInbox(t(lang, "n_lessonEnd"), subject, `${dateISO}|end|${group.id}|${phase.prev.lesson.index}`);
						if (prefs.breakStart && phase.kind === "break") pushInbox(t(lang, "n_breakStart"), subject, `${dateISO}|break|${group.id}|${phase.prev.lesson.index}`);
					}
				}
			}
			if (prefs.tasks) for (const task of data.tasks) {
				if (!canSeeTask(data, profile, task)) continue;
				if (task.due !== dateISO || task.status === "checked") continue;
				pushInbox(t(lang, "n_tasks"), task.title, `${dateISO}|task|${task.id}`);
			}
			if (prefs.personal) for (const event of data.events) {
				if (!canSeeEvent(data, profile, event)) continue;
				if (event.date !== dateISO) continue;
				if (event.kind !== "personal" && event.kind !== "meeting") continue;
				pushInbox(t(lang, "n_personal"), event.title, `${dateISO}|ev|${event.id}`);
			}
		};
		tick();
		const timer = window.setInterval(tick, 2e4);
		return () => window.clearInterval(timer);
	}, [data, pushInbox]);
	(0, import_react.useEffect)(() => {
		if (typeof Notification === "undefined" || Notification.permission !== "granted") return;
		const unread = data.inbox.find((item) => !item.read);
		if (!unread) return;
		const key = `shown:${unread.id}`;
		if (sessionStorage.getItem(key)) return;
		sessionStorage.setItem(key, "1");
		try {
			new Notification(unread.title, { body: unread.body });
		} catch {}
	}, [data.inbox]);
	return null;
}
function OrgsScreen() {
	const data = useMs((s) => s.data);
	const saveOrgName = useMs((s) => s.saveOrgName);
	const addDivision = useMs((s) => s.addDivision);
	const saveClass = useMs((s) => s.saveClass);
	const removeClass = useMs((s) => s.removeClass);
	const saveGroup = useMs((s) => s.saveGroup);
	const removeGroup = useMs((s) => s.removeGroup);
	const saveSubject = useMs((s) => s.saveSubject);
	const removeSubject = useMs((s) => s.removeSubject);
	const addPeriod = useMs((s) => s.addPeriod);
	const setMinorAi = useMs((s) => s.setMinorAi);
	const saveSpace = useMs((s) => s.saveSpace);
	const createSpace = useMs((s) => s.createSpace);
	const lang = data.lang;
	const space = data.spaces.find((item) => item.id === data.activeSpaceId);
	const profile = data.profiles.find((item) => item.id === data.activeProfileId);
	const canEdit = Boolean(profile && space && (canInSpace(profile, space.id, "members", data.customRoles) || canInSpace(profile, space.id, "roles", data.customRoles)));
	const [division, setDivision] = (0, import_react.useState)("");
	const [className, setClassName] = (0, import_react.useState)("");
	const [subject, setSubject] = (0, import_react.useState)("");
	const [groupName, setGroupName] = (0, import_react.useState)("");
	const [periodName, setPeriodName] = (0, import_react.useState)("");
	const [periodStart, setPeriodStart] = (0, import_react.useState)("");
	const [periodEnd, setPeriodEnd] = (0, import_react.useState)("");
	const [homeroom, setHomeroom] = (0, import_react.useState)("");
	const [newName, setNewName] = (0, import_react.useState)("");
	const [newKind, setNewKind] = (0, import_react.useState)("family");
	if (!space) return null;
	const org = data.orgs.find((item) => item.spaceId === space.id);
	const classes = data.classes.filter((item) => item.spaceId === space.id);
	const subjects = data.subjects.filter((item) => item.spaceId === space.id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl",
				children: space.name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: space.kind === "school" ? t(lang, "orgLead") : space.kind === "family" ? t(lang, "familyLead") : t(lang, "personalLead")
			}),
			canEdit ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-start gap-3 rounded-2xl border border-line bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "mt-1 h-5 w-5",
					type: "checkbox",
					checked: space.aiRestrictedForMinors,
					onChange: (event) => setMinorAi(space.id, event.target.checked)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block font-semibold",
					children: t(lang, "minorAi")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm text-muted",
					children: t(lang, "minorAiHint")
				})] })]
			}) : null,
			space.kind !== "school" ? canEdit ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex flex-col gap-2",
				onSubmit: (event) => {
					event.preventDefault();
					const input = event.currentTarget.elements.namedItem("space");
					saveSpace({
						...space,
						name: input.value
					});
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: t(lang, "spaceName"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						name: "space",
						className: controlClass,
						defaultValue: space.name
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					type: "submit",
					children: t(lang, "save")
				})]
			}) : null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				org ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "flex flex-col gap-2",
					onSubmit: (event) => {
						event.preventDefault();
						if (!canEdit) return;
						const input = event.currentTarget.elements.namedItem("org");
						saveOrgName(org.id, input.value);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: t(lang, "orgs"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							name: "org",
							className: controlClass,
							defaultValue: org.name,
							disabled: !canEdit
						})
					}), canEdit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						type: "submit",
						children: t(lang, "save")
					}) : null]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl",
						children: t(lang, "division")
					}),
					data.divisions.filter((item) => item.orgId === org?.id).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm",
						children: item.name
					}, item.id)),
					canEdit && org ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "mt-3 flex flex-col gap-2",
						onSubmit: (event) => {
							event.preventDefault();
							if (!division.trim()) return;
							addDivision(org.id, division.trim());
							setDivision("");
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: controlClass,
							value: division,
							onChange: (event) => setDivision(event.target.value)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							type: "submit",
							children: t(lang, "add")
						})]
					}) : null
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl",
						children: t(lang, "classLabel")
					}),
					classes.map((room) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold",
							children: room.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: data.profiles.find((item) => item.id === room.homeroomTeacherId)?.name ?? t(lang, "none")
						})] }), canEdit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							variant: "danger",
							onClick: () => removeClass(room.id),
							children: t(lang, "delete")
						}) : null]
					}, room.id)),
					canEdit && org ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "mt-3 flex flex-col gap-2",
						onSubmit: (event) => {
							event.preventDefault();
							if (!className.trim()) return;
							saveClass({
								id: uid(),
								spaceId: space.id,
								orgId: org.id,
								divisionId: data.divisions.find((item) => item.orgId === org.id)?.id,
								name: className.trim(),
								homeroomTeacherId: homeroom || void 0
							});
							setClassName("");
							setHomeroom("");
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: controlClass,
								value: className,
								onChange: (event) => setClassName(event.target.value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: t(lang, "homeroomPick"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: controlClass,
									value: homeroom,
									onChange: (event) => setHomeroom(event.target.value),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "—"
									}), data.profiles.filter((item) => item.memberships.some((membership) => membership.spaceId === space.id)).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: item.id,
										children: item.name
									}, item.id))]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								type: "submit",
								children: t(lang, "add")
							})
						]
					}) : null
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl",
						children: t(lang, "subject")
					}),
					subjects.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.name }), canEdit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							variant: "ghost",
							onClick: () => removeSubject(item.id),
							children: t(lang, "delete")
						}) : null]
					}, item.id)),
					canEdit ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "mt-3 flex flex-col gap-2",
						onSubmit: (event) => {
							event.preventDefault();
							if (!subject.trim()) return;
							const tones = [
								"copper",
								"sage",
								"clay",
								"ink"
							];
							saveSubject({
								id: uid(),
								spaceId: space.id,
								name: subject.trim(),
								tone: tones[subjects.length % tones.length] ?? "copper"
							});
							setSubject("");
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: controlClass,
							value: subject,
							onChange: (event) => setSubject(event.target.value),
							placeholder: t(lang, "subjectName")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							type: "submit",
							children: t(lang, "add")
						})]
					}) : null
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl",
						children: t(lang, "group")
					}),
					data.groups.filter((group) => classes.some((room) => room.id === group.classId)).map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: group.name }), canEdit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							variant: "ghost",
							onClick: () => removeGroup(group.id),
							children: t(lang, "delete")
						}) : null]
					}, group.id)),
					canEdit && classes[0] ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "mt-3 flex flex-col gap-2",
						onSubmit: (event) => {
							event.preventDefault();
							const room = classes[0];
							if (!room || !groupName.trim()) return;
							saveGroup({
								id: uid(),
								classId: room.id,
								name: groupName.trim(),
								studentIds: []
							});
							setGroupName("");
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: controlClass,
							value: groupName,
							onChange: (event) => setGroupName(event.target.value)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							type: "submit",
							children: t(lang, "add")
						})]
					}) : null
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl",
						children: t(lang, "period")
					}),
					data.periods.filter((item) => item.orgId === org?.id).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm",
						children: [
							item.name,
							": ",
							item.start,
							" — ",
							item.end
						]
					}, item.id)),
					canEdit && org ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "mt-3 flex flex-col gap-2",
						onSubmit: (event) => {
							event.preventDefault();
							if (!periodName.trim()) return;
							addPeriod(org.id, periodName.trim(), periodStart, periodEnd);
							setPeriodName("");
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: controlClass,
								value: periodName,
								onChange: (event) => setPeriodName(event.target.value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: controlClass,
								type: "date",
								value: periodStart,
								onChange: (event) => setPeriodStart(event.target.value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: controlClass,
								type: "date",
								value: periodEnd,
								onChange: (event) => setPeriodEnd(event.target.value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								type: "submit",
								children: t(lang, "add")
							})
						]
					}) : null
				] })
			] }),
			profile && (canCreateSpace(profile, "family") || canCreateSpace(profile, "personal")) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl",
					children: t(lang, "addSpace")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: t(lang, "addSpaceLead")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-3 flex flex-col gap-2",
					onSubmit: (event) => {
						event.preventDefault();
						if (!newName.trim() || !canCreateSpace(profile, newKind)) return;
						createSpace({
							name: newName.trim(),
							kind: newKind
						});
						setNewName("");
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: controlClass,
							value: newName,
							onChange: (event) => setNewName(event.target.value),
							placeholder: t(lang, "spaceName")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-3 gap-2",
							children: [
								["family", "modeFamily"],
								["personal", "modePersonal"],
								["school", "modeSchool"]
							].map(([value, key]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: !canCreateSpace(profile, value),
								className: `h-11 rounded-xl text-sm font-semibold disabled:opacity-40 ${newKind === value ? "bg-copper text-copper-fg" : "bg-surface-2 text-fg"}`,
								onClick: () => setNewKind(value),
								children: t(lang, key)
							}, value))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							type: "submit",
							disabled: !newName.trim() || !canCreateSpace(profile, newKind),
							children: t(lang, "continue")
						})
					]
				})
			] }) : null
		]
	});
}
var ROLE_LABEL = {
	creator: "role_creator",
	sysadmin: "role_sysadmin",
	orgAdmin: "role_orgAdmin",
	familyAdmin: "role_familyAdmin",
	parent: "role_parent",
	teacher: "role_teacher",
	homeroom: "role_homeroom",
	student: "role_student",
	guest: "role_guest"
};
function PeopleScreen({ onSwitch }) {
	const data = useMs((s) => s.data);
	const saveProfile = useMs((s) => s.saveProfile);
	const removeProfile = useMs((s) => s.removeProfile);
	const setPin = useMs((s) => s.setPin);
	const saveCustomRole = useMs((s) => s.saveCustomRole);
	const joinProfile = useMs((s) => s.joinProfile);
	const lang = data.lang;
	const me = data.profiles.find((item) => item.id === data.activeProfileId);
	const canMembers = Boolean(me && canInSpace(me, data.activeSpaceId, "members", data.customRoles));
	const canRoles = Boolean(me && canInSpace(me, data.activeSpaceId, "roles", data.customRoles));
	const [open, setOpen] = (0, import_react.useState)(false);
	const [roleOpen, setRoleOpen] = (0, import_react.useState)(false);
	const [joinId, setJoinId] = (0, import_react.useState)("");
	const [joinRoles, setJoinRoles] = (0, import_react.useState)(["student"]);
	const visible = data.profiles.filter((profile) => profile.memberships.some((item) => item.spaceId === data.activeSpaceId));
	const outsiders = data.profiles.filter((profile) => !profile.memberships.some((item) => item.spaceId === data.activeSpaceId));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl",
				children: t(lang, "people")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: t(lang, "peopleLead")
			}),
			canMembers ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				onClick: () => setOpen(true),
				children: t(lang, "addPerson")
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: t(lang, "noAccess")
			}),
			visible.map((profile) => {
				const membership = profile.memberships.find((item) => item.spaceId === data.activeSpaceId);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
							name: profile.name,
							tone: profile.tone
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xl",
							children: profile.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: (membership?.roleKeys ?? []).map((key) => isRoleKey(key) ? t(lang, ROLE_LABEL[key]) : data.customRoles.find((role) => role.id === key)?.name ?? key).join(", ")
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							variant: "ghost",
							onClick: () => onSwitch(profile.id),
							children: t(lang, "switchProfile")
						}), canMembers && !profile.isProjectCreator ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							variant: "danger",
							onClick: () => removeProfile(profile.id),
							children: t(lang, "delete")
						}) : null]
					}),
					canMembers ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PinRow, {
						profile,
						onSet: (pin) => setPin(profile.id, pin)
					}) : null
				] }, profile.id);
			}),
			canMembers && outsiders.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl",
					children: t(lang, "joinExisting")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: t(lang, "joinLead")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-3 flex flex-col gap-2",
					onSubmit: (event) => {
						event.preventDefault();
						if (!joinId || joinRoles.length === 0) return;
						joinProfile(joinId, joinRoles);
						setJoinId("");
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: controlClass,
							value: joinId,
							onChange: (event) => setJoinId(event.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "—"
							}), outsiders.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: item.id,
								children: item.name
							}, item.id))]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: ROLE_KEYS.filter((key) => key !== "creator").map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: `h-11 rounded-xl px-3 text-sm font-semibold ${joinRoles.includes(key) ? "bg-copper text-copper-fg" : "bg-surface-2 text-fg"}`,
								onClick: () => setJoinRoles((list) => list.includes(key) ? list.filter((item) => item !== key) : [...list, key]),
								children: t(lang, ROLE_LABEL[key])
							}, key))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							type: "submit",
							disabled: !joinId || joinRoles.length === 0,
							children: t(lang, "add")
						})
					]
				})
			] }) : null,
			canRoles ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-2xl",
					children: t(lang, "customRole")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "ghost",
					onClick: () => setRoleOpen(true),
					children: t(lang, "add")
				}),
				data.customRoles.map((role) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: role.name
				}, role.id)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoleComposer, {
					open: roleOpen,
					onClose: () => setRoleOpen(false),
					onSave: saveCustomRole
				})
			] }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonComposer, {
				open,
				onClose: () => setOpen(false),
				onSave: saveProfile
			})
		]
	});
}
function PinRow({ profile, onSet }) {
	const lang = useMs((s) => s.data.lang);
	const [pin, setPin] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "mt-3 flex gap-2",
		onSubmit: (event) => {
			event.preventDefault();
			if (pin.trim()) onSet(pin.trim());
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: controlClass,
				inputMode: "numeric",
				placeholder: t(lang, "pinPh"),
				value: pin,
				onChange: (event) => setPin(event.target.value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				type: "submit",
				children: t(lang, "setPin")
			}),
			profile.pin ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				variant: "ghost",
				onClick: () => onSet(void 0),
				children: t(lang, "clearPin")
			}) : null
		]
	});
}
function PersonComposer({ open, onClose, onSave }) {
	const data = useMs((s) => s.data);
	const lang = data.lang;
	const [name, setName] = (0, import_react.useState)("");
	const [roles, setRoles] = (0, import_react.useState)(["student"]);
	const [classId, setClassId] = (0, import_react.useState)("");
	const [childIds, setChildIds] = (0, import_react.useState)([]);
	const classes = data.classes.filter((item) => item.spaceId === data.activeSpaceId);
	const students = data.profiles.filter((item) => item.memberships.some((membership) => membership.roleKeys.includes("student")));
	if (!open) return null;
	const toggle = (key) => setRoles((list) => list.includes(key) ? list.filter((item) => item !== key) : [...list, key]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
		open,
		title: t(lang, "addPerson"),
		onClose,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "yourName"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: controlClass,
					value: name,
					onChange: (event) => setName(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: t(lang, "roles")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [ROLE_KEYS.filter((key) => key !== "creator").map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `h-11 rounded-xl px-3 text-sm font-semibold ${roles.includes(key) ? "bg-copper text-copper-fg" : "bg-surface-2 text-fg"}`,
					onClick: () => toggle(key),
					children: t(lang, ROLE_LABEL[key])
				}, key)), data.customRoles.map((role) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `h-11 rounded-xl px-3 text-sm font-semibold ${roles.includes(role.id) ? "bg-copper text-copper-fg" : "bg-surface-2 text-fg"}`,
					onClick: () => toggle(role.id),
					children: role.name
				}, role.id))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "classLabel"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: controlClass,
					value: classId,
					onChange: (event) => setClassId(event.target.value),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "—"
					}), classes.map((room) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: room.id,
						children: room.name
					}, room.id))]
				})
			}),
			roles.includes("parent") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: t(lang, "children")
				}), students.map((student) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex h-11 items-center gap-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: childIds.includes(student.id),
						onChange: () => setChildIds((list) => list.includes(student.id) ? list.filter((id) => id !== student.id) : [...list, student.id])
					}), student.name]
				}, student.id))]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				disabled: !name.trim() || roles.length === 0,
				onClick: () => {
					onSave({
						id: uid(),
						name: name.trim(),
						tone: "sage",
						memberships: [{
							spaceId: data.activeSpaceId,
							roleKeys: roles,
							classId: classId || void 0,
							childIds: childIds.length ? childIds : void 0
						}]
					});
					onClose();
				},
				children: t(lang, "save")
			})
		]
	});
}
function RoleComposer({ open, onClose, onSave }) {
	const lang = useMs((s) => s.data.lang);
	const [name, setName] = (0, import_react.useState)("");
	const [grants, setGrants] = (0, import_react.useState)(blankGrants());
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
		open,
		title: t(lang, "customRole"),
		onClose,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "roleName"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: controlClass,
					value: name,
					onChange: (event) => setName(event.target.value)
				})
			}),
			ACTIONS.map((action) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex h-11 items-center gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: grants[action],
					onChange: () => setGrants((current) => ({
						...current,
						[action]: !current[action]
					}))
				}), action]
			}, action)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				disabled: !name.trim(),
				onClick: () => {
					onSave({
						id: uid(),
						name: name.trim(),
						grants
					});
					onClose();
				},
				children: t(lang, "save")
			})
		]
	});
}
var WEEK = [
	1,
	2,
	3,
	4,
	5,
	6,
	7
];
function ScheduleScreen() {
	const data = useMs((s) => s.data);
	const saveLesson = useMs((s) => s.saveLesson);
	const deleteLesson = useMs((s) => s.deleteLesson);
	const copyDay = useMs((s) => s.copyDay);
	useMs((s) => s.saveException);
	const updateBell = useMs((s) => s.updateBell);
	const lang = data.lang;
	const profile = data.profiles.find((item) => item.id === data.activeProfileId);
	const groups = watchGroups(data, profile);
	const [groupId, setGroupId] = (0, import_react.useState)(groups[0]?.id ?? "");
	const group = groups.find((item) => item.id === groupId) ?? groups[0];
	const [date, setDate] = (0, import_react.useState)(toISODate(/* @__PURE__ */ new Date()));
	const [lessonOpen, setLessonOpen] = (0, import_react.useState)(null);
	const [copyOpen, setCopyOpen] = (0, import_react.useState)(false);
	const [targets, setTargets] = (0, import_react.useState)([]);
	const [bellOpen, setBellOpen] = (0, import_react.useState)(false);
	const [exOpen, setExOpen] = (0, import_react.useState)(false);
	const space = data.spaces.find((item) => item.id === group?.spaceId);
	const canEdit = Boolean(profile && space && canInSpace(profile, space.id, "schedule", data.customRoles));
	const weekday = isoWeekday(fromISODate(date));
	const rows = (0, import_react.useMemo)(() => {
		if (!group || !space) return [];
		return resolveDay(space.bell, data.lessons, data.exceptions, date, weekday, {
			classId: group.teacherId ? void 0 : group.classId,
			ownerProfileId: group.ownerProfileId,
			teacherId: group.teacherId
		});
	}, [
		data.exceptions,
		data.lessons,
		date,
		group,
		space,
		weekday
	]);
	if (!group || !space) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: t(lang, "noLessons")
	});
	const subjects = data.subjects.filter((item) => item.spaceId === space.id);
	const teachers = data.profiles.filter((item) => item.memberships.some((membership) => membership.spaceId === space.id && (membership.roleKeys.includes("teacher") || membership.roleKeys.includes("homeroom"))));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-3xl",
					children: t(lang, "schedule")
				}), canEdit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "ghost",
					onClick: () => setBellOpen(true),
					children: t(lang, "bells")
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "myWatch"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: controlClass,
					value: group.id,
					onChange: (event) => setGroupId(event.target.value),
					children: groups.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: item.id,
						children: item.label
					}, item.id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "date"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: controlClass,
					type: "date",
					value: date,
					onChange: (event) => setDate(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 overflow-x-auto",
				children: WEEK.map((day) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: cn("h-11 shrink-0 rounded-xl px-3 text-sm font-semibold", day === weekday ? "bg-copper text-copper-fg" : "bg-surface text-fg"),
					onClick: () => {
						const base = fromISODate(date);
						const delta = day - isoWeekday(base);
						base.setDate(base.getDate() + delta);
						setDate(toISODate(base));
					},
					children: t(lang, `wd${day}`)
				}, day))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: t(lang, `wd${weekday}`)
			}),
			rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: t(lang, "noLessons")
			}) : null,
			rows.map((row) => {
				const subject = subjectOf(data, row.subjectId);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: cn("border-l-4", toneBorder(subject?.tone), row.cancelled && "opacity-60"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm tabular-nums text-muted",
							children: [
								formatHHMM(row.startMin),
								"–",
								formatHHMM(row.endMin),
								" · ",
								t(lang, "lesson").replace("{n}", String(row.lesson.index))
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xl",
							children: subject?.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [
								t(lang, "room"),
								": ",
								row.room || "—",
								" · ",
								personName(data, row.teacherId)
							]
						}),
						row.cancelled ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-clay",
							children: [t(lang, "cancelled"), row.note ? ` · ${row.note}` : ""]
						}) : null,
						!row.cancelled && row.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-copper",
							children: [
								t(lang, "replaced"),
								" · ",
								row.note
							]
						}) : null,
						canEdit && !group.teacherId ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								variant: "ghost",
								onClick: () => setLessonOpen(row.lesson),
								children: t(lang, "edit")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								variant: "danger",
								onClick: () => deleteLesson(row.lesson.id),
								children: t(lang, "delete")
							})]
						}) : null
					]
				}, row.lesson.id);
			}),
			canEdit && !group.teacherId ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						onClick: () => {
							const used = new Set(rows.map((row) => row.lesson.index));
							let index = 1;
							while (used.has(index) && index < 12) index += 1;
							setLessonOpen({
								id: uid(),
								spaceId: space.id,
								classId: group.classId,
								ownerProfileId: group.ownerProfileId,
								weekday,
								index,
								subjectId: subjects[0]?.id ?? "",
								teacherId: null,
								room: ""
							});
						},
						children: t(lang, "addLesson")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						variant: "ghost",
						onClick: () => {
							setTargets([]);
							setCopyOpen(true);
						},
						children: t(lang, "copyDay")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						variant: "ghost",
						onClick: () => setExOpen(true),
						children: t(lang, "exception")
					})
				]
			}) : null,
			!canEdit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: t(lang, "noAccess")
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LessonModal, {
				lesson: lessonOpen,
				subjects,
				teachers,
				onClose: () => setLessonOpen(null),
				onSave: (lesson) => {
					saveLesson(lesson);
					setLessonOpen(null);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
				open: copyOpen,
				title: t(lang, "copyDay"),
				onClose: () => setCopyOpen(false),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: t(lang, "copyTo")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: WEEK.filter((day) => day !== weekday).map((day) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: cn("h-11 rounded-xl px-3 text-sm font-semibold", targets.includes(day) ? "bg-copper text-copper-fg" : "bg-surface-2 text-fg"),
							onClick: () => setTargets((list) => list.includes(day) ? list.filter((item) => item !== day) : [...list, day]),
							children: t(lang, `wd${day}`)
						}, day))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						onClick: () => {
							const sample = rows[0]?.lesson;
							if (sample) copyDay(sample, targets);
							setCopyOpen(false);
						},
						children: t(lang, "save")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExceptionModal, {
				open: exOpen,
				date,
				group,
				spaceId: space.id,
				onClose: () => setExOpen(false)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BellModal, {
				open: bellOpen,
				bell: space.bell,
				onClose: () => setBellOpen(false),
				onSave: (bell) => {
					updateBell(space.id, bell);
					setBellOpen(false);
				}
			})
		]
	});
}
function LessonModal({ lesson, subjects, teachers, onClose, onSave }) {
	const lang = useMs((s) => s.data.lang);
	const [draft, setDraft] = (0, import_react.useState)(null);
	const current = draft && lesson && draft.id === lesson.id ? draft : lesson;
	if (!current) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
		open: Boolean(lesson),
		title: t(lang, "addLesson"),
		onClose,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "index"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: controlClass,
					type: "number",
					min: 1,
					max: 12,
					value: current.index,
					onChange: (event) => setDraft({
						...current,
						index: Math.min(12, Math.max(1, Number(event.target.value) || 1))
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "subject"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: controlClass,
					value: current.subjectId,
					onChange: (event) => setDraft({
						...current,
						subjectId: event.target.value
					}),
					children: subjects.map((subject) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: subject.id,
						children: subject.name
					}, subject.id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "teacher"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: controlClass,
					value: current.teacherId ?? "",
					onChange: (event) => setDraft({
						...current,
						teacherId: event.target.value || null
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "—"
					}), teachers.map((teacher) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: teacher.id,
						children: teacher.name
					}, teacher.id))]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "room"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: controlClass,
					value: current.room,
					onChange: (event) => setDraft({
						...current,
						room: event.target.value
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				onClick: () => onSave(current),
				disabled: !current.subjectId,
				children: t(lang, "save")
			})
		]
	});
}
function ExceptionModal({ open, date, group, spaceId, onClose }) {
	const lang = useMs((s) => s.data.lang);
	const subjects = useMs((s) => s.data.subjects.filter((item) => item.spaceId === spaceId));
	const saveException = useMs((s) => s.saveException);
	const [index, setIndex] = (0, import_react.useState)(1);
	const [kind, setKind] = (0, import_react.useState)("cancel");
	const [subjectId, setSubjectId] = (0, import_react.useState)(subjects[0]?.id ?? "");
	const [room, setRoom] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
		open,
		title: t(lang, "exception"),
		onClose,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "index"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: controlClass,
					type: "number",
					min: 1,
					max: 12,
					value: index,
					onChange: (event) => setIndex(Number(event.target.value) || 1)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: kind === "cancel" ? "primary" : "ghost",
					onClick: () => setKind("cancel"),
					children: t(lang, "exCancel")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: kind === "replace" ? "primary" : "ghost",
					onClick: () => setKind("replace"),
					children: t(lang, "exReplace")
				})]
			}),
			kind === "replace" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "subject"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: controlClass,
					value: subjectId,
					onChange: (event) => setSubjectId(event.target.value),
					children: subjects.map((subject) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: subject.id,
						children: subject.name
					}, subject.id))
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "room"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: controlClass,
					value: room,
					onChange: (event) => setRoom(event.target.value)
				})
			})] }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "note"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: controlClass,
					value: note,
					onChange: (event) => setNote(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				onClick: () => {
					saveException({
						id: uid(),
						spaceId,
						classId: group.classId,
						date,
						lessonIndex: index,
						kind,
						subjectId: kind === "replace" ? subjectId : void 0,
						room: room || void 0,
						note: note || void 0
					});
					onClose();
				},
				children: t(lang, "save")
			})
		]
	});
}
function BellModal({ open, bell, onClose, onSave }) {
	const lang = useMs((s) => s.data.lang);
	const [draft, setDraft] = (0, import_react.useState)(bell);
	if (!open) return null;
	const current = draft.firstStart === bell.firstStart && draft.lessonMinutes === bell.lessonMinutes ? draft : draft;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
		open,
		title: t(lang, "bellSettings"),
		onClose,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "firstLesson"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: controlClass,
					type: "time",
					value: current.firstStart,
					onChange: (event) => setDraft({
						...current,
						firstStart: event.target.value
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "lessonLen"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: controlClass,
					type: "number",
					min: 20,
					max: 90,
					value: current.lessonMinutes,
					onChange: (event) => setDraft({
						...current,
						lessonMinutes: Number(event.target.value) || 45
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "breakLen"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: controlClass,
					type: "number",
					min: 0,
					max: 40,
					value: current.breakMinutes,
					onChange: (event) => setDraft({
						...current,
						breakMinutes: Number(event.target.value) || 0
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "bigBreak"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: controlClass,
					type: "number",
					min: 0,
					max: 60,
					value: current.bigBreakMinutes,
					onChange: (event) => setDraft({
						...current,
						bigBreakMinutes: Number(event.target.value) || 0
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "bigAfter"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: controlClass,
					type: "number",
					min: 1,
					max: 11,
					value: current.bigBreakAfter[0] ?? 3,
					onChange: (event) => setDraft({
						...current,
						bigBreakAfter: [Number(event.target.value) || 3]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "perDay"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: controlClass,
					type: "number",
					min: 1,
					max: 12,
					value: current.lessonsPerDay,
					onChange: (event) => setDraft({
						...current,
						lessonsPerDay: Math.min(12, Number(event.target.value) || 1)
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				onClick: () => onSave(current),
				children: t(lang, "save")
			})
		]
	});
}
function SettingsScreen() {
	const data = useMs((s) => s.data);
	const setLang = useMs((s) => s.setLang);
	const setTheme = useMs((s) => s.setTheme);
	const setNotif = useMs((s) => s.setNotif);
	const importData = useMs((s) => s.importData);
	const resetAll = useMs((s) => s.resetAll);
	const lang = data.lang;
	const profile = data.profiles.find((item) => item.id === data.activeProfileId);
	const canAdmin = Boolean(profile && canInSpace(profile, data.activeSpaceId, "import", data.customRoles) && (profile.memberships.find((item) => item.spaceId === data.activeSpaceId)?.roleKeys ?? []).some((key) => [
		"creator",
		"sysadmin",
		"orgAdmin",
		"familyAdmin"
	].includes(key)));
	const canReset = Boolean(profile?.isProjectCreator || canAdmin);
	const [secrets, setSecrets] = (0, import_react.useState)(false);
	const [message, setMessage] = (0, import_react.useState)("");
	const [perm, setPerm] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl",
				children: t(lang, "settings")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-xl",
				children: t(lang, "theme")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid grid-cols-3 gap-2",
				children: [
					["light", "themeLight"],
					["dark", "themeDark"],
					["system", "themeSystem"]
				].map(([value, key]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: data.theme === value ? "primary" : "ghost",
					onClick: () => setTheme(value),
					children: t(lang, key)
				}, value))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-xl",
				children: t(lang, "language")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid grid-cols-3 gap-2",
				children: [
					"ru",
					"uk",
					"en"
				].map((code) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: lang === code ? "primary" : "ghost",
					onClick: () => setLang(code),
					children: code.toUpperCase()
				}, code))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl",
					children: t(lang, "notif")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: t(lang, "notifHint")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 flex flex-col gap-2",
					children: [
						["lessonStart", "n_lessonStart"],
						["lessonEnd", "n_lessonEnd"],
						["breakStart", "n_breakStart"],
						["breakEnd", "n_breakEnd"],
						["remind15", "n_remind15"],
						["remind5", "n_remind5"],
						["tasks", "n_tasks"],
						["personal", "n_personal"]
					].map(([key, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex h-11 items-center justify-between gap-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, label) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: data.notif[key],
							onChange: (event) => setNotif(key, event.target.checked)
						})]
					}, key))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					className: "mt-3",
					variant: "ghost",
					onClick: async () => {
						if (typeof Notification === "undefined") {
							setPerm(t(lang, "notifDenied"));
							return;
						}
						const result = await Notification.requestPermission();
						setPerm(result === "granted" ? t(lang, "notifGranted") : t(lang, "notifDenied"));
					},
					children: t(lang, "notifBrowser")
				}),
				perm ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: perm
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted",
					children: t(lang, "cloudNotif")
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl",
					children: t(lang, "exportJson")
				}),
				canAdmin ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-3 flex h-11 items-center gap-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: secrets,
						onChange: (event) => setSecrets(event.target.checked)
					}), t(lang, "includeSecrets")]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							onClick: () => downloadText("metashkola.json", JSON.stringify(redactSecrets(data, secrets), null, 2), "application/json"),
							children: t(lang, "exportJson")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "inline-flex h-11 cursor-pointer items-center rounded-xl bg-surface-2 px-4 text-sm font-semibold",
							children: [t(lang, "importJson"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "sr-only",
								type: "file",
								accept: "application/json",
								onChange: async (event) => {
									const file = event.target.files?.[0];
									if (!file) return;
									try {
										const raw = JSON.parse(await file.text());
										const result = importData(raw, "merge");
										setMessage(result.ok ? t(lang, "imported") : t(lang, "err_format"));
									} catch {
										setMessage(t(lang, "err_format"));
									}
								}
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							variant: "ghost",
							onClick: async () => {
								const input = document.createElement("input");
								input.type = "file";
								input.accept = "application/json";
								input.onchange = async () => {
									const file = input.files?.[0];
									if (!file) return;
									try {
										const raw = JSON.parse(await file.text());
										const result = importData(raw, "replace");
										setMessage(result.ok ? t(lang, "imported") : t(lang, "err_format"));
									} catch {
										setMessage(t(lang, "err_format"));
									}
								};
								input.click();
							},
							children: t(lang, "replace")
						})
					]
				})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: t(lang, "noAccess")
				}),
				message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-sage",
					children: message
				}) : null
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl",
					children: t(lang, "about")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm",
					children: t(lang, "aboutBody")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: t(lang, "authorLine")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-4 text-lg",
					children: t(lang, "architecture")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm",
					children: t(lang, "archOk")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: t(lang, "archNo")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: t(lang, "delivery")
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-xl",
				children: t(lang, "audit")
			}), data.audit.slice(0, 12).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: item.text
			}, item.id))] }),
			canReset ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				variant: "danger",
				onClick: () => {
					if (window.confirm(t(lang, "resetConfirm"))) resetAll();
				},
				children: t(lang, "reset")
			}) : null
		]
	});
}
function statusKey(status) {
	if (status === "progress") return "st_progress";
	if (status === "done") return "st_done";
	if (status === "checked") return "st_checked";
	if (status === "returned") return "st_returned";
	return "st_assigned";
}
function priorityKey(priority) {
	if (priority === "high") return "pr_high";
	if (priority === "low") return "pr_low";
	return "pr_normal";
}
function TasksScreen() {
	const data = useMs((s) => s.data);
	const setTaskStatus = useMs((s) => s.setTaskStatus);
	const addComment = useMs((s) => s.addComment);
	const saveTask = useMs((s) => s.saveTask);
	const removeTask = useMs((s) => s.removeTask);
	const saveGrade = useMs((s) => s.saveGrade);
	const removeGrade = useMs((s) => s.removeGrade);
	const lang = data.lang;
	const profile = data.profiles.find((item) => item.id === data.activeProfileId);
	const spaceId = data.activeSpaceId;
	const [openOnly, setOpenOnly] = (0, import_react.useState)(true);
	const [selected, setSelected] = (0, import_react.useState)(null);
	const [composer, setComposer] = (0, import_react.useState)(false);
	const [gradeOpen, setGradeOpen] = (0, import_react.useState)(false);
	const [note, setNote] = (0, import_react.useState)("");
	const canTasks = Boolean(profile && canInSpace(profile, spaceId, "tasks", data.customRoles));
	const canGrades = Boolean(profile && canInSpace(profile, spaceId, "grades", data.customRoles));
	const tasks = data.tasks.filter((task) => canSeeTask(data, profile, task)).filter((task) => openOnly ? task.status !== "checked" : true).sort((a, b) => a.due.localeCompare(b.due));
	const grades = data.grades.filter((grade) => canSeeGrade(data, profile, grade));
	const current = tasks.find((task) => task.id === selected) ?? null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-3xl",
					children: t(lang, "tasks")
				}), canTasks ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					onClick: () => setComposer(true),
					children: t(lang, "add")
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: openOnly ? "primary" : "ghost",
					onClick: () => setOpenOnly(true),
					children: t(lang, "allOpen")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: !openOnly ? "primary" : "ghost",
					onClick: () => setOpenOnly(false),
					children: t(lang, "allTasks")
				})]
			}),
			tasks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: t(lang, "noTasks")
			}) : null,
			tasks.map((task) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "rounded-2xl border border-line bg-surface p-4 text-left",
				onClick: () => {
					setSelected(task.id);
					setNote("");
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							data.spaces.find((space) => space.id === task.spaceId)?.name,
							" · ",
							subjectOf(data, task.subjectId)?.name,
							" · ",
							task.due
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl",
						children: task.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm",
						children: [
							personName(data, task.assigneeId),
							" · ",
							t(lang, statusKey(task.status)),
							" · ",
							t(lang, priorityKey(task.priority))
						]
					})
				]
			}, task.id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-2xl",
				children: t(lang, "grades")
			}),
			canGrades ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				variant: "ghost",
				onClick: () => setGradeOpen(true),
				children: t(lang, "newGrade")
			}) : null,
			grades.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: t(lang, "none")
			}) : null,
			grades.map((grade) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-semibold",
					children: [
						personName(data, grade.studentId),
						" · ",
						subjectOf(data, grade.subjectId)?.name
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-3xl tabular-nums",
					children: grade.score
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [grade.date, grade.comment ? ` · ${grade.comment}` : ""]
				}),
				canGrades ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "danger",
					className: "mt-2",
					onClick: () => removeGrade(grade.id),
					children: t(lang, "delete")
				}) : null
			] }, grade.id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
				open: Boolean(current),
				title: current?.title ?? "",
				onClose: () => setSelected(null),
				children: current ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskBody, {
					task: current,
					note,
					setNote,
					canTasks,
					isAssignee: current.assigneeId === profile?.id,
					onStatus: (status) => profile && setTaskStatus(current.id, status, profile.id),
					onComment: () => {
						if (!profile || !note.trim()) return;
						addComment(current.id, profile.id, note.trim());
						setNote("");
					},
					onDelete: () => {
						removeTask(current.id);
						setSelected(null);
					}
				}) : null
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskComposer, {
				open: composer,
				spaceId,
				onClose: () => setComposer(false),
				onSave: saveTask
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GradeComposer, {
				open: gradeOpen,
				spaceId,
				onClose: () => setGradeOpen(false),
				onSave: (grade) => {
					saveGrade(grade);
					setGradeOpen(false);
				}
			}),
			profile && membershipOf(profile, spaceId)?.roleKeys.includes("guest") ? null : null
		]
	});
}
function TaskBody({ task, note, setNote, canTasks, isAssignee, onStatus, onComment, onDelete }) {
	const data = useMs((s) => s.data);
	const lang = data.lang;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-sm text-muted",
			children: [
				t(lang, "due"),
				": ",
				task.due,
				" · ",
				t(lang, priorityKey(task.priority))
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: task.detail }),
		task.attachments.map((file) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			className: "text-sm font-semibold text-copper",
			href: file.href,
			target: "_blank",
			rel: "noreferrer",
			children: file.name
		}, file.id)),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm font-semibold",
			children: t(lang, statusKey(task.status))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap gap-2",
			children: [
				isAssignee && (task.status === "assigned" || task.status === "returned") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					onClick: () => onStatus("progress"),
					children: t(lang, "takeProgress")
				}) : null,
				isAssignee && (task.status === "progress" || task.status === "assigned") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					onClick: () => onStatus("done"),
					children: t(lang, "markDone")
				}) : null,
				canTasks ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					onClick: () => onStatus("checked"),
					children: t(lang, "markChecked")
				}) : null,
				canTasks ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "ghost",
					onClick: () => onStatus("returned"),
					children: t(lang, "markReturned")
				}) : null
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "text-lg",
			children: t(lang, "comments")
		}),
		task.comments.map((comment) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "font-semibold",
				children: [personName(data, comment.authorId), ". "]
			}), comment.text]
		}, comment.id)),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: t(lang, "comment"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				className: areaClass,
				value: note,
				onChange: (event) => setNote(event.target.value)
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
			variant: "ghost",
			onClick: onComment,
			children: t(lang, "save")
		}),
		task.history.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "text-lg",
			children: t(lang, "history")
		}), task.history.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: item.text
		}, item.at + item.text))] }) : null,
		canTasks ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
			variant: "danger",
			onClick: onDelete,
			children: t(lang, "delete")
		}) : null
	] });
}
function TaskComposer({ open, spaceId, onClose, onSave }) {
	const data = useMs((s) => s.data);
	const lang = data.lang;
	const profile = data.profiles.find((item) => item.id === data.activeProfileId);
	const [title, setTitle] = (0, import_react.useState)("");
	const [detail, setDetail] = (0, import_react.useState)("");
	const [due, setDue] = (0, import_react.useState)(toISODate(/* @__PURE__ */ new Date()));
	const [priority, setPriority] = (0, import_react.useState)("normal");
	const [assigneeId, setAssigneeId] = (0, import_react.useState)("");
	const [subjectId, setSubjectId] = (0, import_react.useState)("");
	const [href, setHref] = (0, import_react.useState)("");
	const [fileNote, setFileNote] = (0, import_react.useState)("");
	const students = data.profiles.filter((item) => item.memberships.some((membership) => membership.spaceId === spaceId && membership.roleKeys.includes("student")));
	const subjects = data.subjects.filter((item) => item.spaceId === spaceId);
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
		open,
		title: t(lang, "newTask"),
		onClose,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "title"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: controlClass,
					value: title,
					onChange: (event) => setTitle(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "detail"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: areaClass,
					value: detail,
					onChange: (event) => setDetail(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "assignee"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: controlClass,
					value: assigneeId,
					onChange: (event) => setAssigneeId(event.target.value),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "—"
					}), students.map((student) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: student.id,
						children: student.name
					}, student.id))]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "subject"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: controlClass,
					value: subjectId,
					onChange: (event) => setSubjectId(event.target.value),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "—"
					}), subjects.map((subject) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: subject.id,
						children: subject.name
					}, subject.id))]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "due"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: controlClass,
					type: "date",
					value: due,
					onChange: (event) => setDue(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "priority"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: controlClass,
					value: priority,
					onChange: (event) => setPriority(event.target.value),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "low",
							children: t(lang, "pr_low")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "normal",
							children: t(lang, "pr_normal")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "high",
							children: t(lang, "pr_high")
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "attachment"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: controlClass,
					placeholder: t(lang, "linkPh"),
					value: href,
					onChange: (event) => setHref(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "attachment"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: controlClass,
					type: "file",
					onChange: (event) => {
						const file = event.target.files?.[0];
						if (!file) return;
						if (file.size > 18e4) {
							setFileNote(t(lang, "fileLimit"));
							return;
						}
						const reader = new FileReader();
						reader.onload = () => {
							if (typeof reader.result === "string") setHref(reader.result);
						};
						reader.readAsDataURL(file);
					}
				})
			}),
			fileNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-clay",
				children: fileNote
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				disabled: !title.trim() || !assigneeId,
				onClick: () => {
					const classId = data.profiles.find((item) => item.id === assigneeId)?.memberships.find((item) => item.classId)?.classId;
					onSave({
						id: uid(),
						spaceId,
						assigneeId,
						classId,
						subjectId: subjectId || void 0,
						title: title.trim(),
						detail: detail.trim(),
						due,
						priority,
						status: "assigned",
						teacherId: profile?.id,
						comments: [],
						attachments: href ? [{
							id: uid(),
							name: href.startsWith("data:") ? "file" : href,
							href
						}] : [],
						history: [{
							at: (/* @__PURE__ */ new Date()).toISOString(),
							text: "created"
						}]
					});
					onClose();
				},
				children: t(lang, "save")
			})
		]
	});
}
function GradeComposer({ open, spaceId, onClose, onSave }) {
	const data = useMs((s) => s.data);
	const lang = data.lang;
	const profile = data.profiles.find((item) => item.id === data.activeProfileId);
	const [studentId, setStudentId] = (0, import_react.useState)("");
	const [subjectId, setSubjectId] = (0, import_react.useState)("");
	const [score, setScore] = (0, import_react.useState)(10);
	const [comment, setComment] = (0, import_react.useState)("");
	const students = data.profiles.filter((item) => item.memberships.some((membership) => membership.spaceId === spaceId && membership.roleKeys.includes("student")));
	const subjects = data.subjects.filter((item) => item.spaceId === spaceId);
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
		open,
		title: t(lang, "newGrade"),
		onClose,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "assignee"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: controlClass,
					value: studentId,
					onChange: (event) => setStudentId(event.target.value),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "—"
					}), students.map((student) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: student.id,
						children: student.name
					}, student.id))]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "subject"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: controlClass,
					value: subjectId,
					onChange: (event) => setSubjectId(event.target.value),
					children: subjects.map((subject) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: subject.id,
						children: subject.name
					}, subject.id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "score"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: controlClass,
					type: "number",
					min: 1,
					max: 12,
					value: score,
					onChange: (event) => setScore(Math.min(12, Math.max(1, Number(event.target.value) || 1)))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t(lang, "comment"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: controlClass,
					value: comment,
					onChange: (event) => setComment(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				disabled: !studentId || !subjectId,
				onClick: () => onSave({
					id: uid(),
					spaceId,
					studentId,
					subjectId,
					teacherId: profile?.id,
					score,
					kind: "mark",
					date: toISODate(/* @__PURE__ */ new Date()),
					comment
				}),
				children: t(lang, "save")
			})
		]
	});
}
var PRIMARY = [
	{
		id: "home",
		key: "home",
		icon: House
	},
	{
		id: "schedule",
		key: "schedule",
		icon: CalendarDays
	},
	{
		id: "tasks",
		key: "tasks",
		icon: ListChecks
	},
	{
		id: "calendar",
		key: "calendar",
		icon: BookOpen
	},
	{
		id: "more",
		key: "more",
		icon: Ellipsis
	}
];
var ALL = [
	{
		id: "home",
		key: "home",
		icon: House
	},
	{
		id: "schedule",
		key: "schedule",
		icon: CalendarDays
	},
	{
		id: "bells",
		key: "bells",
		icon: Clock
	},
	{
		id: "tasks",
		key: "tasks",
		icon: ListChecks
	},
	{
		id: "calendar",
		key: "calendar",
		icon: BookOpen
	},
	{
		id: "ai",
		key: "ai",
		icon: Sparkles
	},
	{
		id: "people",
		key: "people",
		icon: Users
	},
	{
		id: "orgs",
		key: "orgs",
		icon: Building2
	},
	{
		id: "integrations",
		key: "integrations",
		icon: Cable
	},
	{
		id: "settings",
		key: "settings",
		icon: Settings
	}
];
function isMore(screen) {
	return ![
		"home",
		"schedule",
		"tasks",
		"calendar"
	].includes(screen);
}
function Shell() {
	const data = useMs((s) => s.data);
	const setActiveProfile = useMs((s) => s.setActiveProfile);
	const setActiveSpace = useMs((s) => s.setActiveSpace);
	const markInboxRead = useMs((s) => s.markInboxRead);
	const lang = data.lang;
	const profile = data.profiles.find((item) => item.id === data.activeProfileId);
	const [screen, setScreen] = (0, import_react.useState)("home");
	const [whoOpen, setWhoOpen] = (0, import_react.useState)(false);
	const [inboxOpen, setInboxOpen] = (0, import_react.useState)(false);
	const [unlocked, setUnlocked] = (0, import_react.useState)([]);
	const [pin, setPin] = (0, import_react.useState)("");
	const [pinBad, setPinBad] = (0, import_react.useState)(false);
	const [pendingId, setPendingId] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const root = document.documentElement;
		root.classList.remove("theme-dark", "theme-light");
		if (data.theme === "dark") root.classList.add("theme-dark");
		if (data.theme === "light") root.classList.add("theme-light");
		root.lang = lang;
	}, [data.theme, lang]);
	const lockedProfile = profile?.pin && !unlocked.includes(profile.id) ? profile : null;
	const pending = data.profiles.find((item) => item.id === pendingId);
	const gateProfile = lockedProfile ?? (pending?.pin && !unlocked.includes(pending.id) ? pending : null);
	const unread = data.inbox.filter((item) => !item.read).length;
	const spaces = data.spaces.filter((space) => profile?.memberships.some((item) => item.spaceId === space.id));
	const chooseProfile = (id) => {
		const next = data.profiles.find((item) => item.id === id);
		if (!next) return;
		if (next.pin && !unlocked.includes(next.id)) {
			setPendingId(id);
			setPin("");
			setPinBad(false);
			setWhoOpen(false);
			return;
		}
		setActiveProfile(id);
		setWhoOpen(false);
		setScreen("home");
	};
	const submitPin = () => {
		if (!gateProfile) return;
		if (pin === gateProfile.pin) {
			setUnlocked((list) => [...list, gateProfile.id]);
			if (pendingId === gateProfile.id) setActiveProfile(gateProfile.id);
			setPendingId(null);
			setPin("");
			setPinBad(false);
			setScreen("home");
			return;
		}
		setPinBad(true);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-bg text-fg md:flex",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notifier, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "hidden w-64 shrink-0 flex-col gap-1 border-r border-line bg-surface p-3 md:flex",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-3 py-4 font-display text-2xl",
					children: t(lang, "appName")
				}), ALL.map((item) => {
					const Icon = item.icon;
					const active = screen === item.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						"data-testid": `nav-${item.id}`,
						className: cn("flex h-11 items-center gap-3 rounded-xl px-3 text-left text-sm font-semibold", active ? "bg-copper text-copper-fg" : "text-fg"),
						onClick: () => setScreen(item.id),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-5 w-5" }), t(lang, item.key)]
					}, item.id);
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-1 flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "sticky top-0 z-20 flex items-center gap-2 border-b border-line bg-bg px-3 py-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-semibold tracking-wide text-copper",
										children: t(lang, "appName")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "sr-only",
										htmlFor: "space-switch",
										children: t(lang, "switchSpace")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										id: "space-switch",
										className: "w-full truncate bg-transparent text-base font-semibold text-fg",
										value: data.activeSpaceId,
										onChange: (event) => setActiveSpace(event.target.value),
										children: spaces.map((space) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: space.id,
											children: space.name
										}, space.id))
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "relative inline-flex h-11 w-11 items-center justify-center rounded-full border border-line",
								"aria-label": t(lang, "inbox"),
								onClick: () => {
									setInboxOpen(true);
									markInboxRead();
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "h-5 w-5" }), unread > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "absolute right-1 top-1 inline-flex h-5 min-w-5 items-center justify-center rounded-full bg-copper px-1 text-xs font-semibold text-copper-fg",
									children: unread
								}) : null]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"data-testid": "profile-switch",
								"aria-label": t(lang, "switchProfile"),
								onClick: () => setWhoOpen(true),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
									name: profile?.name ?? "?",
									tone: profile?.tone ?? "ink"
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
						className: "nav-pad mx-auto flex w-full max-w-3xl flex-col gap-4 px-4 py-4",
						"data-screen": screen,
						children: [
							screen === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeScreen, { onOpen: setScreen }) : null,
							screen === "schedule" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScheduleScreen, {}) : null,
							screen === "bells" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BellsScreen, {}) : null,
							screen === "tasks" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TasksScreen, {}) : null,
							screen === "calendar" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarScreen, {}) : null,
							screen === "ai" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AiScreen, {}) : null,
							screen === "people" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PeopleScreen, { onSwitch: chooseProfile }) : null,
							screen === "orgs" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrgsScreen, {}) : null,
							screen === "integrations" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IntegrationsScreen, {}) : null,
							screen === "settings" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsScreen, {}) : null,
							screen === "more" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-2 gap-3",
								children: ALL.filter((item) => ![
									"home",
									"schedule",
									"tasks",
									"calendar"
								].includes(item.id)).map((item) => {
									const Icon = item.icon;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										"data-testid": `more-${item.id}`,
										className: "flex h-24 flex-col items-start justify-between rounded-2xl border border-line bg-surface p-4 text-left",
										onClick: () => setScreen(item.id),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-5 w-5 text-copper" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-semibold",
											children: t(lang, item.key)
										})]
									}, item.id);
								})
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "dock-safe fixed inset-x-0 bottom-0 z-20 border-t border-line bg-surface md:hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-5",
							children: PRIMARY.map((item) => {
								const Icon = item.icon;
								const active = item.id === "more" ? isMore(screen) : screen === item.id;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									"data-testid": `tab-${item.id}`,
									className: cn("flex h-16 flex-col items-center justify-center gap-1 text-xs font-semibold", active ? "text-copper" : "text-muted"),
									onClick: () => setScreen(item.id),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-5 w-5" }), t(lang, item.key)]
								}, item.id);
							})
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
				open: whoOpen,
				title: t(lang, "switchProfile"),
				onClose: () => setWhoOpen(false),
				children: data.profiles.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "flex h-14 items-center gap-3 rounded-xl px-1 text-left",
					onClick: () => chooseProfile(item.id),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
						name: item.name,
						tone: item.tone
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold",
						children: item.name
					})]
				}, item.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
				open: inboxOpen,
				title: t(lang, "inbox"),
				onClose: () => setInboxOpen(false),
				children: [data.inbox.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: t(lang, "inboxEmpty")
				}) : null, data.inbox.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "border-b border-line py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: item.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: item.body
					})]
				}, item.id))]
			}),
			gateProfile ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center bg-bg px-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "flex w-full max-w-sm flex-col gap-3",
					onSubmit: (event) => {
						event.preventDefault();
						submitPin();
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-3xl",
							children: t(lang, "pinTitle")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold",
							children: gateProfile.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "PIN",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: controlClass,
								inputMode: "numeric",
								autoComplete: "off",
								value: pin,
								onChange: (event) => setPin(event.target.value)
							})
						}),
						pinBad ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-clay",
							children: t(lang, "pinWrong")
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							type: "submit",
							children: t(lang, "unlock")
						}),
						pendingId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							variant: "ghost",
							onClick: () => {
								setPendingId(null);
								setPin("");
								setPinBad(false);
							},
							children: t(lang, "cancel")
						}) : null
					]
				})
			}) : null
		]
	});
}
function Welcome({ locked = false }) {
	const data = useMs((s) => s.data);
	const setLang = useMs((s) => s.setLang);
	const openDemo = useMs((s) => s.openDemo);
	const openEmpty = useMs((s) => s.openEmpty);
	const lang = data.lang;
	const [empty, setEmpty] = (0, import_react.useState)(false);
	const [name, setName] = (0, import_react.useState)("");
	const [spaceName, setSpaceName] = (0, import_react.useState)("");
	const [kind, setKind] = (0, import_react.useState)("family");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-screen w-full max-w-lg flex-col justify-center gap-6 px-4 py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-col gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold tracking-wide text-copper",
						children: t(lang, "appName")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-4xl text-fg",
						children: t(lang, "welcomeTitle")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-base text-muted",
						children: t(lang, "welcomeLead")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2",
				children: [
					"ru",
					"uk",
					"en"
				].map((code) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `h-11 rounded-xl px-4 text-sm font-semibold ${lang === code ? "bg-copper text-copper-fg" : "bg-surface text-fg"}`,
					onClick: () => setLang(code),
					children: code.toUpperCase()
				}, code))
			}),
			!empty ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						"data-testid": "welcome-demo",
						disabled: locked,
						onClick: () => openDemo(),
						children: t(lang, "openDemo")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: t(lang, "demoHint")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						variant: "ghost",
						"data-testid": "welcome-empty",
						disabled: locked,
						onClick: () => setEmpty(true),
						children: t(lang, "startEmpty")
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex flex-col gap-3",
				onSubmit: (event) => {
					event.preventDefault();
					openEmpty({
						name,
						spaceName,
						kind,
						lang
					});
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: t(lang, "yourName"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: controlClass,
							value: name,
							onChange: (event) => setName(event.target.value),
							required: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: t(lang, "spaceName"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: controlClass,
							value: spaceName,
							onChange: (event) => setSpaceName(event.target.value),
							required: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-3 gap-2",
						children: [
							["family", "modeFamily"],
							["personal", "modePersonal"],
							["school", "modeSchool"]
						].map(([value, key]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `h-11 rounded-xl text-sm font-semibold ${kind === value ? "bg-copper text-copper-fg" : "bg-surface text-fg"}`,
							onClick: () => setKind(value),
							children: t(lang, key)
						}, value))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						type: "submit",
						children: t(lang, "continue")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						variant: "ghost",
						onClick: () => setEmpty(false),
						children: t(lang, "cancel")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: t(lang, "authorLine")
			})
		]
	});
}
function Home() {
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	const bootstrapped = useMs((s) => s.bootstrapped);
	(0, import_react.useEffect)(() => {
		const finish = () => setHydrated(true);
		const unsub = useMs.persist.onFinishHydration(finish);
		useMs.persist.rehydrate();
		return unsub;
	}, []);
	if (!hydrated || !bootstrapped) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Welcome, { locked: !hydrated });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {});
}
//#endregion
export { Home as component };
