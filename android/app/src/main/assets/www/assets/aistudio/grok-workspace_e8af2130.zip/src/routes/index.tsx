import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Shell } from "@/components/ms/shell";
import { Welcome } from "@/components/ms/welcome";
import { useMs } from "@/lib/ms/store";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const [hydrated, setHydrated] = useState(false);
  const bootstrapped = useMs((s) => s.bootstrapped);
  useEffect(() => {
    const finish = () => setHydrated(true);
    const unsub = useMs.persist.onFinishHydration(finish);
    void useMs.persist.rehydrate();
    return unsub;
  }, []);
  if (!hydrated || !bootstrapped) return <Welcome locked={!hydrated} />;
  return <Shell />;
}
