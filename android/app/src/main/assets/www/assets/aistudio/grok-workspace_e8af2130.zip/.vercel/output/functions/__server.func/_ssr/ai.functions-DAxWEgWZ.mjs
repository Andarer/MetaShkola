import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { a as object, i as number, n as array, o as string, t as _enum } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ai.functions-DAxWEgWZ.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var messageSchema = object({
	role: _enum([
		"system",
		"user",
		"assistant"
	]),
	content: string().min(1).max(6e3)
});
var chatSchema = object({
	mode: _enum(["builtin", "custom"]),
	baseUrl: string().max(300).optional(),
	apiKey: string().max(500).optional(),
	model: string().min(1).max(120),
	temperature: number().min(0).max(1).optional(),
	messages: array(messageSchema).min(1).max(14)
});
var probeSchema = object({
	mode: _enum(["builtin", "custom"]),
	baseUrl: string().max(300).optional(),
	apiKey: string().max(500).optional()
});
function isPublicHttps(raw) {
	if (!raw) return null;
	let url;
	try {
		url = new URL(raw);
	} catch {
		return null;
	}
	if (url.protocol !== "https:") return null;
	const host = url.hostname.toLowerCase();
	if (!host || host === "localhost" || host.endsWith(".local") || host.endsWith(".internal")) return null;
	if (host.includes(":")) return null;
	if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host)) {
		const [a, b] = host.split(".").map((part) => Number(part));
		if (a === 10 || a === 127 || a === 0 || a === 192 && b === 168 || a === 172 && b >= 16 && b <= 31) return null;
		if (a === 169 && b === 254) return null;
	}
	return url;
}
function endpoint(mode, baseUrl) {
	if (mode === "builtin") {
		const key = process.env.XAI_API_KEY;
		if (!key) return { error: "no_key" };
		return {
			root: "https://api.x.ai/v1",
			key
		};
	}
	return null;
}
async function readJson(res) {
	try {
		return await res.json();
	} catch {
		return null;
	}
}
var askTutor_createServerFn_handler = createServerRpc({
	id: "b134fc1c499c669c146385a719b68437fc5929d3f096f5734c523502741f7e17",
	name: "askTutor",
	filename: "src/lib/ms/ai.functions.ts"
}, (opts) => askTutor.__executeServer(opts));
var askTutor = createServerFn({ method: "POST" }).validator((input) => chatSchema.parse(input)).handler(askTutor_createServerFn_handler, async ({ data }) => {
	try {
		let root = "";
		let key = "";
		if (data.mode === "builtin") {
			const built = endpoint("builtin", void 0);
			if (!built) return {
				ok: false,
				error: "no_key"
			};
			if ("error" in built) return {
				ok: false,
				error: built.error
			};
			root = built.root;
			key = built.key;
		} else {
			const url = isPublicHttps(data.baseUrl);
			if (!url || !data.apiKey) return {
				ok: false,
				error: data.apiKey ? "bad_url" : "no_key"
			};
			root = url.toString().replace(/\/$/, "");
			key = data.apiKey;
		}
		const res = await fetch(`${root}/chat/completions`, {
			method: "POST",
			redirect: "manual",
			signal: AbortSignal.timeout(25e3),
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${key}`
			},
			body: JSON.stringify({
				model: data.model,
				temperature: data.temperature ?? .4,
				max_tokens: 700,
				messages: data.messages
			})
		});
		if (res.status >= 300 && res.status < 400) return {
			ok: false,
			error: "bad_url",
			detail: "redirect"
		};
		if (!res.ok) return {
			ok: false,
			error: "upstream",
			detail: `HTTP ${res.status}`
		};
		const body = await readJson(res);
		const text = body?.choices?.[0]?.message?.content?.trim() ?? "";
		if (!text) return {
			ok: false,
			error: "empty"
		};
		return {
			ok: true,
			text,
			model: body?.model || data.model,
			promptTokens: body?.usage?.prompt_tokens ?? 0,
			completionTokens: body?.usage?.completion_tokens ?? 0
		};
	} catch {
		return {
			ok: false,
			error: "network"
		};
	}
});
var probeModels_createServerFn_handler = createServerRpc({
	id: "901ee8d50ebdbf3eaf90c1ab6c0486388b9ad8856a67f77c14b5ff202dcf2080",
	name: "probeModels",
	filename: "src/lib/ms/ai.functions.ts"
}, (opts) => probeModels.__executeServer(opts));
var probeModels = createServerFn({ method: "POST" }).validator((input) => probeSchema.parse(input)).handler(probeModels_createServerFn_handler, async ({ data }) => {
	try {
		let root = "";
		let key = "";
		if (data.mode === "builtin") {
			const built = endpoint("builtin", void 0);
			if (!built) return {
				ok: false,
				error: "no_key"
			};
			if ("error" in built) return {
				ok: false,
				error: built.error
			};
			root = built.root;
			key = built.key;
		} else {
			const url = isPublicHttps(data.baseUrl);
			if (!url || !data.apiKey) return {
				ok: false,
				error: data.apiKey ? "bad_url" : "no_key"
			};
			root = url.toString().replace(/\/$/, "");
			key = data.apiKey;
		}
		const res = await fetch(`${root}/models`, {
			method: "GET",
			redirect: "manual",
			signal: AbortSignal.timeout(2e4),
			headers: { Authorization: `Bearer ${key}` }
		});
		if (res.status >= 300 && res.status < 400) return {
			ok: false,
			error: "bad_url",
			detail: "redirect"
		};
		if (!res.ok) return {
			ok: false,
			error: "upstream",
			detail: `HTTP ${res.status}`
		};
		return {
			ok: true,
			models: ((await readJson(res))?.data ?? []).map((item) => item.id).filter((id) => Boolean(id)).slice(0, 40)
		};
	} catch {
		return {
			ok: false,
			error: "network"
		};
	}
});
//#endregion
export { askTutor_createServerFn_handler, probeModels_createServerFn_handler };
